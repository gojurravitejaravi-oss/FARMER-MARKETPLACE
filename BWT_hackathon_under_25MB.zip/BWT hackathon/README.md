# 🏛️ Campus Complaint Management System

> **Tagline:** *Report. Track. Resolve.*  
> **Built for:** BWT Hackathon — Production-Ready MERN Stack Implementation

---

## 📖 1. Project Overview

### Problem Statement
In educational institutions, students frequently encounter infrastructure breakdowns involving classrooms, laboratories, washrooms, electrical fixtures, campus Wi-Fi, and cleanliness. Traditional physical complaint registers or informal emails result in lost grievances, absence of accountability, zero status transparency, and delayed resolutions.

### Solution
**CampusResolve** is a full-stack MERN web application providing an end-to-end digital grievance workflow:
- **Students** submit categorized issues with location tags, urgency levels, and photo attachments. Every submission receives a unique reference number (`CMP-2026-XXXXX`) and real-time tracking timeline.
- **Administrators** monitor system-wide trends via interactive dashboards, prioritize critical issues, assign departments, and commit official status updates with audited remarks.

---

## 🛠️ 2. Technology Stack

- **Frontend:** React 19, Vite 8, Tailwind CSS, Lucide React, Recharts, React Router v7
- **Backend:** Node.js, Express.js (REST API architecture)
- **Database:** MongoDB with Mongoose ODM (real database persistence)
- **Authentication:** JWT (JSON Web Tokens) with cryptographically secure `bcryptjs` password hashing
- **Security:** Helmet headers, CORS origin isolation, Express rate-limiting, strict Role-Based Access Control (RBAC), and mass-assignment protection
- **Process Management:** `concurrently` for running frontend and backend together

---

## 📂 3. Project Structure

```text
campus-complaint-management/
│
├── frontend/                     # React + Vite Client
│   ├── public/                   # Static assets & favicon
│   ├── src/
│   │   ├── components/           # Reusable UI (Navbar, Sidebar, Badges, StatCards, Spinners)
│   │   ├── context/              # AuthContext and ToastContext
│   │   ├── layouts/              # PublicLayout & DashboardLayout
│   │   ├── pages/                # Landing, Login, Register, Dashboards, Complaints, Profile
│   │   ├── services/             # Axios API client with Bearer token interceptor
│   │   ├── App.jsx               # Protected role-based route tree
│   │   ├── index.css             # Tailwind CSS & custom design system tokens
│   │   └── main.jsx              # React DOM entry
│   ├── .env.example              # Frontend environment variables template
│   ├── .env                      # Local client environment config
│   ├── package.json              # Frontend scripts & dependencies
│   └── vite.config.js            # Vite build configuration
│
├── backend/                      # Express.js REST API
│   ├── config/                   # MongoDB connection logic (db.js)
│   ├── controllers/              # Auth, Complaint, Dashboard, and User controllers
│   ├── middleware/               # Auth (protect, adminOnly), Error handler, Multer upload
│   ├── models/                   # Mongoose Schemas (User, Complaint, Category)
│   ├── routes/                   # Auth, Complaints, Dashboard, and User routes
│   ├── scripts/                  # Safe database seeder (seed.js)
│   ├── tests/                    # Automated verification suite (api.test.js)
│   ├── uploads/                  # Secure file attachment storage
│   ├── .env.example              # Backend environment variables template
│   ├── .env                      # Local server environment config
│   ├── package.json              # Backend scripts & dependencies
│   └── server.js                 # Express server bootstrap & DB gatekeeper
│
├── docs/
│   └── API_DOCUMENTATION.md      # Full REST API endpoint reference
├── .gitignore                    # Git tracking rules
├── package.json                  # Root development scripts (concurrently)
└── README.md                     # Comprehensive setup and user guide
```

---

## ⚙️ 4. Prerequisites

1. **Node.js:** Version 18.x or 20.x or higher (tested on Node v24)
2. **npm:** Version 9.x or higher
3. **MongoDB:**
   - **Option A (Local):** Local MongoDB Community Server running on `mongodb://127.0.0.1:27017`
   - **Option B (Cloud):** MongoDB Atlas connection string (`mongodb+srv://...`)

---

## 🚀 5. Installation & Setup

### Step 1: Install Dependencies
From the project root, run:
```bash
npm run install:all
```
*(Or install individually: `npm install && cd backend && npm install && cd ../frontend && npm install`)*

### Step 2: Configure Environment Variables

**Backend (`backend/.env`):**
```env
PORT=5000
NODE_ENV=development
MONGODB_URI=mongodb://127.0.0.1:27017/campus_complaints
JWT_SECRET=super_secret_jwt_key_campus_complaint_2026_dev
JWT_EXPIRES_IN=7d
CLIENT_URL=http://localhost:5173
```

**Frontend (`frontend/.env`):**
```env
VITE_API_URL=http://localhost:5000/api
```

---

## 🛡️ 6. Initializing Administrators & Sample Data

To prevent public exploitation, administrative privileges cannot be self-assigned during registration. Initialize the primary administrator and realistic sample grievances using the backend seed utility:

```bash
npm run seed:admin
```
*(Or from root: `npm run seed`)*

### Pre-Configured Demo Accounts:
| Role | Email | Password |
| :--- | :--- | :--- |
| **Administrator** | `admin@campus.edu` | `Admin@123456` |
| **Student (Demo 1)** | `student@campus.edu` | `Student@123456` |
| **Student (Demo 2)** | `priya.verma@campus.edu` | `Student@123456` |

*Note: The login page includes 1-click demo autofill buttons for immediate evaluation.*

---

## 🏃 7. Running the Application

### Start Both Servers Concurrently:
```bash
npm run dev
```

### Or Run Individually:
- **Frontend only:** `npm run dev:frontend` (starts Vite on http://localhost:5173)
- **Backend only:** `npm run dev:backend` (starts Express on http://localhost:5000)

### Access Links:
- 🌐 **Frontend Application:** [http://localhost:5173](http://localhost:5173)
- 🔌 **Backend API:** [http://localhost:5000](http://localhost:5000)
- 🩺 **Health Check Endpoint:** [http://localhost:5000/api/health](http://localhost:5000/api/health)

---

## 🧪 8. Automated Testing & Verification

Run the automated backend test suite covering 17 critical acceptance criteria:
```bash
npm test
```
**Verification Scope:**
- Database connectivity & health endpoint response
- Student registration & password hashing
- Duplicate email rejection (400 Bad Request)
- Successful login & invalid credential rejection (401 Unauthorized)
- Role verification for Administrator
- Complaint lodging with `Pending` initial status & unique reference code
- Student access restricted strictly to their own grievances
- Cross-student access blocked (403 Forbidden)
- Student access to administrator endpoints blocked (403 Forbidden)
- Administrator retrieval of all campus complaints
- Status transition updates with live `statusHistory` logging
- Timestamp recording on `Resolved` status
- Real-time MongoDB metrics on student and admin dashboards
- Mass-assignment protection preventing role escalation

---

## 🏗️ 9. Building for Production

To create an optimized production build of the frontend:
```bash
npm run build
```
The output will be bundled inside `frontend/dist/`.

---

## 🔧 10. Troubleshooting & FAQ

### 1. PowerShell Script Execution Policy Error (`npm.ps1 cannot be loaded`)
If Windows blocks PowerShell scripts, execute commands via `npm.cmd` or run:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

### 2. MongoDB Connection Failure
The backend intentionally aborts startup with an actionable error if MongoDB is unreachable.
- Check if local MongoDB service is running:
  ```powershell
  Get-Service -Name "*mongo*"
  Start-Service -Name "MongoDB"
  ```
- If using MongoDB Atlas, update `MONGODB_URI` in `backend/.env` and verify your IP is whitelisted in Atlas Network Access.

### 3. Port Conflicts (Port 5000 or 5173 occupied)
- Check which process occupies the port:
  ```powershell
  Get-NetTCPConnection -LocalPort 5000, 5173
  ```
- If needed, adjust `PORT` in `backend/.env` and `VITE_API_URL` in `frontend/.env`.

---

## 🛑 11. Stopping the Application
To stop both running servers safely:
- Press `Ctrl + C` in the active terminal window running `npm run dev`.
- Type `Y` when prompted to terminate batch job.
