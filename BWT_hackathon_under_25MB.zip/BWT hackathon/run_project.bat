@echo off
title Campus Complaint Management System - Runner
echo ========================================================
echo   Campus Complaint Management System
echo   Tagline: Report. Track. Resolve.
echo ========================================================
echo.
echo Starting Frontend (http://localhost:5173) and Backend (http://localhost:5000)...
echo.
npm.cmd run dev
pause
