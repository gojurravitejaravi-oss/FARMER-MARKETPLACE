# Campus Complaint Management System — REST API Documentation

**Tagline:** Report. Track. Resolve.  
**Base URL:** `http://localhost:5000/api`  
**Authentication Scheme:** Bearer Token via `Authorization: Bearer <jwt_token>` header.

---

## 1. System Health & Diagnostics

### `GET /api/health`
Checks server uptime and verified database connectivity.
- **Access:** Public
- **Response `200 OK`:**
```json
{
  "status": "ok",
  "service": "Campus Complaint Management System API",
  "uptime": 128,
  "timestamp": "2026-10-09T15:20:00.000Z",
  "database": "connected",
  "environment": "development"
}
```

---

## 2. Authentication Endpoints (`/api/auth`)

### `POST /api/auth/register`
Registers a new student account. (Role is strictly locked to `student` by backend).
- **Access:** Public
- **Request Body:**
```json
{
  "name": "Aarav Sharma",
  "email": "aarav.sharma@campus.edu",
  "studentId": "CS-2026-042",
  "department": "Computer Science & Engineering",
  "phone": "+91 98111 22334",
  "password": "Password@123",
  "confirmPassword": "Password@123"
}
```
- **Response `201 Created`:**
```json
{
  "success": true,
  "message": "Registration successful. Welcome to Campus Complaint Management!",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "6ac906e0bc9d5c58600f7a5f",
    "name": "Aarav Sharma",
    "email": "aarav.sharma@campus.edu",
    "studentId": "CS-2026-042",
    "department": "Computer Science & Engineering",
    "role": "student",
    "phone": "+91 98111 22334",
    "createdAt": "2026-10-09T15:21:00.000Z"
  }
}
```

### `POST /api/auth/login`
Authenticates a student or administrator using verified bcrypt password hash.
- **Access:** Public
- **Request Body:**
```json
{
  "email": "student@campus.edu",
  "password": "Student@123456"
}
```
- **Response `200 OK`:**
```json
{
  "success": true,
  "message": "Welcome back, Aarav Sharma!",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "6ac906e0bc9d5c58600f7a5f",
    "name": "Aarav Sharma",
    "email": "student@campus.edu",
    "role": "student"
  }
}
```

### `GET /api/auth/me`
Retrieves currently authenticated session identity.
- **Access:** Private (`Bearer <token>`)
- **Response `200 OK`:** Returns current sanitized user object.

### `POST /api/auth/logout`
Terminates user session.
- **Access:** Private (`Bearer <token>`)
- **Response `200 OK`:** `{ "success": true, "message": "Logged out successfully." }`

---

## 3. Complaint Management Endpoints (`/api/complaints`)

### `POST /api/complaints`
Lodges a new campus grievance. Automatically generates an immutable complaint number and sets initial status to `Pending`.
- **Access:** Private (`student`)
- **Content-Type:** `multipart/form-data` or `application/json`
- **Fields:**
  - `title` (string, required): Summary of problem
  - `category` (string, required): One of `Electricity`, `Water Supply`, `Cleanliness`, `Washroom`, `Classroom`, `Laboratory`, `Furniture`, `Internet / Wi-Fi`, `Safety and Security`, `Other`
  - `location` (string, required): Building / Area
  - `roomNumber` (string, optional): Specific room or workbench
  - `priority` (string, optional): `Low`, `Medium`, or `High` (default `Medium`)
  - `description` (string, required): Detailed problem explanation
  - `attachment` (file, optional): JPG, PNG, WebP image (max 5MB)
- **Response `201 Created`:**
```json
{
  "success": true,
  "message": "Complaint submitted successfully.",
  "complaintNumber": "CMP-2026-10482",
  "complaint": {
    "_id": "6ac906e0bc9d5c58600f7a60",
    "complaintNumber": "CMP-2026-10482",
    "title": "Broken AC in CS Lab 3",
    "category": "Classroom",
    "location": "Academic Block B",
    "roomNumber": "Lab 301",
    "priority": "High",
    "status": "Pending",
    "student": "6ac906e0bc9d5c58600f7a5f",
    "statusHistory": [
      {
        "previousStatus": null,
        "newStatus": "Pending",
        "timestamp": "2026-10-09T15:25:00.000Z",
        "updatedByName": "Aarav Sharma",
        "remarks": "Complaint submitted by student"
      }
    ],
    "createdAt": "2026-10-09T15:25:00.000Z"
  }
}
```

### `GET /api/complaints`
Retrieves complaints with search, category filtering, status filtering, and pagination.
- **Access:** Private
  - *Students:* Strictly returns only their own submitted records.
  - *Admins:* Returns all campus grievances.
- **Query Parameters:**
  - `search` (string): Keyword filter for ID, title, or location
  - `status` (string): `Pending`, `In Progress`, `Resolved`, `Rejected`
  - `category` (string): Filter by specific domain
  - `priority` (string): `Low`, `Medium`, `High`
  - `sort` (string): e.g. `-createdAt`, `createdAt`
  - `page` (number): Page number (default: 1)
  - `limit` (number): Page limit (default: 10)
- **Response `200 OK`:**
```json
{
  "success": true,
  "count": 10,
  "total": 45,
  "totalPages": 5,
  "currentPage": 1,
  "complaints": [...]
}
```

### `GET /api/complaints/:id`
Retrieves complete ticket metadata and full status audit timeline.
- **Access:** Private
  - Accessible by ticket owner or any administrator.
  - Cross-student access is rejected with `403 Forbidden`.
- **Response `200 OK`:** Returns complaint document populated with student info and timeline.

### `PATCH /api/complaints/:id/status`
Updates official status, assigns maintenance department, and appends timestamped administrative audit entry.
- **Access:** Private (`admin` only)
- **Request Body:**
```json
{
  "status": "In Progress",
  "adminRemarks": "Spare motor ordered. Electrician dispatched.",
  "assignedDepartment": "Electrical Maintenance",
  "assignedTo": "Rajesh Sharma (Electrician)"
}
```
- **Response `200 OK`:** Returns updated complaint with updated `statusHistory`.

### `PATCH /api/complaints/:id`
Allows modifying complaint fields. Students can only update their own complaints if still in `Pending` state.
- **Access:** Private

### `DELETE /api/complaints/:id`
Deletes a complaint record. Students can only delete their own complaints if still in `Pending` state. Administrators can delete any record.
- **Access:** Private

---

## 4. Dashboards (`/api/dashboard`)

### `GET /api/dashboard/student`
Returns personalized metrics for the logged-in student.
- **Access:** Private (`student`)
- **Response `200 OK`:**
```json
{
  "success": true,
  "data": {
    "stats": {
      "total": 4,
      "pending": 1,
      "inProgress": 2,
      "resolved": 1,
      "rejected": 0
    },
    "recentComplaints": [...],
    "recentActivities": [...]
  }
}
```

### `GET /api/dashboard/admin`
Returns campus-wide metrics, Recharts category and priority aggregations, and high-priority escalation items.
- **Access:** Private (`admin` only)
- **Response `200 OK`:**
```json
{
  "success": true,
  "data": {
    "stats": {
      "total": 24,
      "pending": 6,
      "inProgress": 10,
      "resolved": 7,
      "rejected": 1,
      "totalStudents": 18
    },
    "categoryStats": [
      { "category": "Electricity", "count": 9 },
      { "category": "Washroom", "count": 6 }
    ],
    "priorityStats": [
      { "priority": "High", "count": 11 }
    ],
    "recentComplaints": [...],
    "attentionRequired": [...]
  }
}
```

---

## 5. User Profile (`/api/users`)

### `GET /api/users/me`
Retrieves authenticated profile.

### `PATCH /api/users/me`
Updates user details (`name`, `department`, `phone`, `studentId`).  
*Security Notice:* Modifying `role` or `email` is strictly prevented.
