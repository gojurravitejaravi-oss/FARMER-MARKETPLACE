const jwt = require('jsonwebtoken');

const signToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET || 'dev_secret_key_change_in_prod', {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });
};

const sendTokenResponse = (user, statusCode, res, message = 'Success') => {
  const token = signToken(user._id);

  // Return formatted JSON response
  res.status(statusCode).json({
    success: true,
    message,
    token,
    user: {
      id: user._id,
      name: user.name,
      email: user.email,
      studentId: user.studentId,
      department: user.department,
      role: user.role,
      phone: user.phone || '',
      createdAt: user.createdAt,
    },
  });
};

module.exports = {
  signToken,
  sendTokenResponse,
};
