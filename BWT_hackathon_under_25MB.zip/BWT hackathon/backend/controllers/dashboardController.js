const Complaint = require('../models/Complaint');
const User = require('../models/User');

// @desc    Get dashboard statistics for the logged-in student
// @route   GET /api/dashboard/student
// @access  Private (Student)
exports.getStudentDashboard = async (req, res, next) => {
  try {
    const studentId = req.user._id;

    const [total, pending, inProgress, resolved, rejected, recentComplaints] =
      await Promise.all([
        Complaint.countDocuments({ student: studentId }),
        Complaint.countDocuments({ student: studentId, status: 'Pending' }),
        Complaint.countDocuments({ student: studentId, status: 'In Progress' }),
        Complaint.countDocuments({ student: studentId, status: 'Resolved' }),
        Complaint.countDocuments({ student: studentId, status: 'Rejected' }),
        Complaint.find({ student: studentId })
          .sort('-createdAt')
          .limit(5),
      ]);

    // Extract recent timeline activities from student's complaints
    const recentActivities = [];
    recentComplaints.forEach((c) => {
      if (c.statusHistory && c.statusHistory.length > 0) {
        c.statusHistory.forEach((h) => {
          recentActivities.push({
            complaintId: c._id,
            complaintNumber: c.complaintNumber,
            title: c.title,
            previousStatus: h.previousStatus,
            newStatus: h.newStatus,
            timestamp: h.timestamp,
            updatedByName: h.updatedByName,
            remarks: h.remarks,
          });
        });
      }
    });

    // Sort recent activities by timestamp descending
    recentActivities.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    res.status(200).json({
      success: true,
      data: {
        stats: {
          total,
          pending,
          inProgress,
          resolved,
          rejected,
        },
        recentComplaints,
        recentActivities: recentActivities.slice(0, 6),
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get dashboard statistics for administrator
// @route   GET /api/dashboard/admin
// @access  Private (Admin)
exports.getAdminDashboard = async (req, res, next) => {
  try {
    const [
      total,
      pending,
      inProgress,
      resolved,
      rejected,
      totalStudents,
      recentComplaints,
      categoryStats,
      priorityStats,
      attentionRequired,
    ] = await Promise.all([
      Complaint.countDocuments(),
      Complaint.countDocuments({ status: 'Pending' }),
      Complaint.countDocuments({ status: 'In Progress' }),
      Complaint.countDocuments({ status: 'Resolved' }),
      Complaint.countDocuments({ status: 'Rejected' }),
      User.countDocuments({ role: 'student' }),
      Complaint.find()
        .populate('student', 'name email studentId department')
        .sort('-createdAt')
        .limit(6),
      Complaint.aggregate([
        { $group: { _id: '$category', count: { $sum: 1 } } },
        { $project: { category: '$_id', count: 1, _id: 0 } },
        { $sort: { count: -1 } },
      ]),
      Complaint.aggregate([
        { $group: { _id: '$priority', count: { $sum: 1 } } },
        { $project: { priority: '$_id', count: 1, _id: 0 } },
      ]),
      Complaint.find({
        $or: [{ priority: 'High', status: { $in: ['Pending', 'In Progress'] } }, { status: 'Pending' }],
      })
        .populate('student', 'name email department')
        .sort({ priority: -1, createdAt: 1 })
        .limit(5),
    ]);

    res.status(200).json({
      success: true,
      data: {
        stats: {
          total,
          pending,
          inProgress,
          resolved,
          rejected,
          totalStudents,
        },
        categoryStats,
        priorityStats,
        recentComplaints,
        attentionRequired,
      },
    });
  } catch (error) {
    next(error);
  }
};
