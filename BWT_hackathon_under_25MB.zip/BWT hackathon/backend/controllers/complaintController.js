const Complaint = require('../models/Complaint');

// Helper to generate unique complaint reference code
const generateComplaintNumber = async () => {
  const year = new Date().getFullYear();
  let unique = false;
  let code = '';

  while (!unique) {
    const random = Math.floor(10000 + Math.random() * 90000);
    code = `CMP-${year}-${random}`;
    const existing = await Complaint.findOne({ complaintNumber: code });
    if (!existing) {
      unique = true;
    }
  }

  return code;
};

// @desc    Submit a new complaint
// @route   POST /api/complaints
// @access  Private (Student)
exports.createComplaint = async (req, res, next) => {
  try {
    const { title, description, category, location, roomNumber, priority } = req.body;

    if (!title || !description || !category || !location) {
      return res.status(400).json({
        success: false,
        message: 'Please provide title, description, category, and location.',
      });
    }

    const complaintNumber = await generateComplaintNumber();

    // Check if an image was uploaded
    let attachmentUrl = '';
    if (req.file) {
      attachmentUrl = `/uploads/${req.file.filename}`;
    }

    const complaint = await Complaint.create({
      complaintNumber,
      title: title.trim(),
      description: description.trim(),
      category,
      location: location.trim(),
      roomNumber: roomNumber ? roomNumber.trim() : '',
      priority: priority || 'Medium',
      status: 'Pending',
      student: req.user._id,
      attachmentUrl,
      statusHistory: [
        {
          previousStatus: null,
          newStatus: 'Pending',
          timestamp: new Date(),
          updatedBy: req.user._id,
          updatedByName: req.user.name,
          remarks: 'Complaint submitted by student',
        },
      ],
    });

    res.status(201).json({
      success: true,
      message: 'Complaint submitted successfully.',
      complaintNumber: complaint.complaintNumber,
      complaint,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get complaints (students get their own, admins get all) with search, filter & pagination
// @route   GET /api/complaints
// @access  Private
exports.getComplaints = async (req, res, next) => {
  try {
    const {
      search,
      status,
      category,
      priority,
      sort = '-createdAt',
      page = 1,
      limit = 10,
    } = req.query;

    const query = {};

    // Ownership check: students only see their complaints
    if (req.user.role === 'student') {
      query.student = req.user._id;
    }

    // Filter by status
    if (status && status !== 'all') {
      query.status = status;
    }

    // Filter by category
    if (category && category !== 'all') {
      query.category = category;
    }

    // Filter by priority
    if (priority && priority !== 'all') {
      query.priority = priority;
    }

    // Search keyword across complaintNumber, title, location, description
    if (search && search.trim()) {
      const searchRegex = new RegExp(search.trim(), 'i');
      query.$or = [
        { complaintNumber: searchRegex },
        { title: searchRegex },
        { location: searchRegex },
        { description: searchRegex },
      ];
    }

    const pageNum = parseInt(page, 10) || 1;
    const limitNum = parseInt(limit, 10) || 10;
    const skip = (pageNum - 1) * limitNum;

    const total = await Complaint.countDocuments(query);
    const complaints = await Complaint.find(query)
      .populate('student', 'name email studentId department phone')
      .sort(sort)
      .skip(skip)
      .limit(limitNum);

    res.status(200).json({
      success: true,
      count: complaints.length,
      total,
      totalPages: Math.ceil(total / limitNum) || 1,
      currentPage: pageNum,
      complaints,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get complaint details by ID or complaintNumber
// @route   GET /api/complaints/:id
// @access  Private
exports.getComplaintById = async (req, res, next) => {
  try {
    const { id } = req.params;

    let complaint;
    if (id.startsWith('CMP-')) {
      complaint = await Complaint.findOne({ complaintNumber: id }).populate(
        'student',
        'name email studentId department phone'
      );
    } else {
      complaint = await Complaint.findById(id).populate(
        'student',
        'name email studentId department phone'
      );
    }

    if (!complaint) {
      return res.status(404).json({
        success: false,
        message: 'Complaint not found.',
      });
    }

    // Security Authorization: Student can only view their own complaint
    if (
      req.user.role === 'student' &&
      complaint.student._id.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized. You do not have permission to view this complaint.',
      });
    }

    res.status(200).json({
      success: true,
      complaint,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update complaint status, remarks and assignment (Admin Only)
// @route   PATCH /api/complaints/:id/status
// @access  Private (Admin)
exports.updateComplaintStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status, adminRemarks, resolutionNotes, assignedDepartment, assignedTo } = req.body;

    if (!status) {
      return res.status(400).json({
        success: false,
        message: 'Please specify the updated status.',
      });
    }

    const validStatuses = ['Pending', 'In Progress', 'Resolved', 'Rejected'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Status must be one of: ${validStatuses.join(', ')}`,
      });
    }

    const complaint = await Complaint.findById(id);
    if (!complaint) {
      return res.status(404).json({
        success: false,
        message: 'Complaint not found.',
      });
    }

    const oldStatus = complaint.status;

    // Append to status history
    complaint.statusHistory.push({
      previousStatus: oldStatus,
      newStatus: status,
      timestamp: new Date(),
      updatedBy: req.user._id,
      updatedByName: `${req.user.name} (Admin)`,
      remarks: adminRemarks || resolutionNotes || `Status updated from ${oldStatus} to ${status}`,
    });

    complaint.status = status;
    if (adminRemarks !== undefined) complaint.adminRemarks = adminRemarks.trim();
    if (resolutionNotes !== undefined) complaint.resolutionNotes = resolutionNotes.trim();
    if (assignedDepartment !== undefined) complaint.assignedDepartment = assignedDepartment.trim();
    if (assignedTo !== undefined) complaint.assignedTo = assignedTo.trim();

    if (status === 'Resolved') {
      complaint.resolvedAt = new Date();
    } else if (oldStatus === 'Resolved' && status !== 'Resolved') {
      complaint.resolvedAt = null; // Reopened
    }

    await complaint.save();

    const updatedComplaint = await Complaint.findById(id).populate(
      'student',
      'name email studentId department phone'
    );

    res.status(200).json({
      success: true,
      message: `Complaint ${complaint.complaintNumber} updated to ${status}.`,
      complaint: updatedComplaint,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update complaint content (Student can update only if Pending; Admin can update fields)
// @route   PATCH /api/complaints/:id
// @access  Private
exports.updateComplaint = async (req, res, next) => {
  try {
    const { id } = req.params;
    const complaint = await Complaint.findById(id);

    if (!complaint) {
      return res.status(404).json({
        success: false,
        message: 'Complaint not found.',
      });
    }

    // Role check
    if (req.user.role === 'student') {
      if (complaint.student.toString() !== req.user._id.toString()) {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized. You cannot edit another student\'s complaint.',
        });
      }

      if (complaint.status !== 'Pending') {
        return res.status(400).json({
          success: false,
          message: `Cannot edit complaint once it is ${complaint.status}. Please contact an administrator.`,
        });
      }

      const { title, description, category, location, roomNumber, priority } = req.body;
      if (title) complaint.title = title.trim();
      if (description) complaint.description = description.trim();
      if (category) complaint.category = category;
      if (location) complaint.location = location.trim();
      if (roomNumber !== undefined) complaint.roomNumber = roomNumber.trim();
      if (priority) complaint.priority = priority;

      await complaint.save();
    } else {
      // Admin update
      const { title, description, category, location, roomNumber, priority, assignedDepartment, assignedTo } = req.body;
      if (title) complaint.title = title.trim();
      if (description) complaint.description = description.trim();
      if (category) complaint.category = category;
      if (location) complaint.location = location.trim();
      if (roomNumber !== undefined) complaint.roomNumber = roomNumber.trim();
      if (priority) complaint.priority = priority;
      if (assignedDepartment !== undefined) complaint.assignedDepartment = assignedDepartment.trim();
      if (assignedTo !== undefined) complaint.assignedTo = assignedTo.trim();

      await complaint.save();
    }

    const updated = await Complaint.findById(id).populate(
      'student',
      'name email studentId department phone'
    );

    res.status(200).json({
      success: true,
      message: 'Complaint updated successfully.',
      complaint: updated,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete complaint
// @route   DELETE /api/complaints/:id
// @access  Private
exports.deleteComplaint = async (req, res, next) => {
  try {
    const { id } = req.params;
    const complaint = await Complaint.findById(id);

    if (!complaint) {
      return res.status(404).json({
        success: false,
        message: 'Complaint not found.',
      });
    }

    // Check ownership & status
    if (req.user.role === 'student') {
      if (complaint.student.toString() !== req.user._id.toString()) {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized. You cannot delete this complaint.',
        });
      }

      if (complaint.status !== 'Pending') {
        return res.status(400).json({
          success: false,
          message: `Cannot delete a complaint that is already '${complaint.status}'.`,
        });
      }
    }

    await Complaint.findByIdAndDelete(id);

    res.status(200).json({
      success: true,
      message: 'Complaint deleted successfully.',
    });
  } catch (error) {
    next(error);
  }
};
