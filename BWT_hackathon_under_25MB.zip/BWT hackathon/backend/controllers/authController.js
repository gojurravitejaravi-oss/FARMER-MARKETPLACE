const User = require('../models/User');
const { sendTokenResponse } = require('../utils/jwt');

// @desc    Register a new student
// @route   POST /api/auth/register
// @access  Public
exports.register = async (req, res, next) => {
  try {
    const { name, email, studentId, department, password, confirmPassword, phone } = req.body;

    if (!name || !email || !department || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide full name, email, department, and password.',
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.',
      });
    }

    if (confirmPassword && password !== confirmPassword) {
      return res.status(400).json({
        success: false,
        message: 'Passwords do not match.',
      });
    }

    // Check duplicate email
    const existingUser = await User.findOne({ email: email.toLowerCase().trim() });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'An account with this email address already exists. Please log in.',
      });
    }

    // Check duplicate studentId if provided
    if (studentId && studentId.trim()) {
      const existingStudentId = await User.findOne({ studentId: studentId.trim() });
      if (existingStudentId) {
        return res.status(400).json({
          success: false,
          message: 'An account with this Student ID / Roll Number already exists.',
        });
      }
    }

    // Hash password
    const passwordHash = await User.hashPassword(password);

    // Strictly enforce student role on public registration
    const user = await User.create({
      name: name.trim(),
      email: email.toLowerCase().trim(),
      studentId: studentId ? studentId.trim() : undefined,
      department: department.trim(),
      passwordHash,
      role: 'student', // Security requirement: ignore any body.role
      phone: phone ? phone.trim() : '',
    });

    sendTokenResponse(user, 201, res, 'Registration successful. Welcome to Campus Complaint Management!');
  } catch (error) {
    next(error);
  }
};

// @desc    Login user (Student or Admin)
// @route   POST /api/auth/login
// @access  Public
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide both email and password.',
      });
    }

    // Query user and explicitly select passwordHash
    const user = await User.findOne({ email: email.toLowerCase().trim() }).select('+passwordHash');
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password credentials.',
      });
    }

    // Verify password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password credentials.',
      });
    }

    sendTokenResponse(user, 200, res, `Welcome back, ${user.name}!`);
  } catch (error) {
    next(error);
  }
};

// @desc    Get current authenticated user
// @route   GET /api/auth/me
// @access  Private
exports.getMe = async (req, res, next) => {
  try {
    res.status(200).json({
      success: true,
      user: {
        id: req.user._id,
        name: req.user.name,
        email: req.user.email,
        studentId: req.user.studentId,
        department: req.user.department,
        role: req.user.role,
        phone: req.user.phone || '',
        createdAt: req.user.createdAt,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Logout user
// @route   POST /api/auth/logout
// @access  Private
exports.logout = async (req, res, next) => {
  try {
    res.status(200).json({
      success: true,
      message: 'Logged out successfully.',
    });
  } catch (error) {
    next(error);
  }
};
