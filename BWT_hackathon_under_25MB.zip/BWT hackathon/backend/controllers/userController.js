const User = require('../models/User');

// @desc    Get user profile
// @route   GET /api/users/me
// @access  Private
exports.getUserProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);
    res.status(200).json({
      success: true,
      user,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update user profile
// @route   PATCH /api/users/me
// @access  Private
exports.updateUserProfile = async (req, res, next) => {
  try {
    const { name, department, phone, studentId } = req.body;

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found.',
      });
    }

    // Security: never allow modifying role or email via this endpoint
    if (name) user.name = name.trim();
    if (department) user.department = department.trim();
    if (phone !== undefined) user.phone = phone.trim();
    if (studentId !== undefined && user.role === 'student') {
      user.studentId = studentId.trim();
    }

    await user.save();

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully.',
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        studentId: user.studentId,
        department: user.department,
        role: user.role,
        phone: user.phone || '',
        updatedAt: user.updatedAt,
      },
    });
  } catch (error) {
    next(error);
  }
};
