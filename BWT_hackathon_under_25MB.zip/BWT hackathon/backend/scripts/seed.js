const mongoose = require('mongoose');
require('dotenv').config();

const User = require('../models/User');
const Complaint = require('../models/Complaint');

const seedData = async () => {
  const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/campus_complaints';

  try {
    console.log('[SEED] Connecting to MongoDB...');
    await mongoose.connect(uri);
    console.log('[SEED] Connected successfully.');

    // Clear existing sample complaints & demo users if flag provided or clean seed
    const isReset = process.argv.includes('--reset');

    if (isReset) {
      console.log('[SEED] Reset flag detected: Cleaning existing users and complaints...');
      await User.deleteMany({});
      await Complaint.deleteMany({});
    }

    // 1. Seed or find Admin
    let admin = await User.findOne({ email: 'admin@campus.edu' });
    if (!admin) {
      const adminPasswordHash = await User.hashPassword('Admin@123456');
      admin = await User.create({
        name: 'Campus Administrator',
        email: 'admin@campus.edu',
        department: 'Campus Administration & Facilities',
        passwordHash: adminPasswordHash,
        role: 'admin',
        phone: '+91 98765 43210',
      });
      console.log(' [CREATED] Admin user created: admin@campus.edu / Admin@123456');
    } else {
      console.log(' [EXISTS] Admin user already exists: admin@campus.edu');
    }

    // 2. Seed or find Student 1
    let student1 = await User.findOne({ email: 'student@campus.edu' });
    if (!student1) {
      const studentPasswordHash = await User.hashPassword('Student@123456');
      student1 = await User.create({
        name: 'Aarav Sharma',
        email: 'student@campus.edu',
        studentId: 'CS-2026-042',
        department: 'Computer Science & Engineering',
        passwordHash: studentPasswordHash,
        role: 'student',
        phone: '+91 98111 22334',
      });
      console.log(' [CREATED] Student user created: student@campus.edu / Student@123456');
    } else {
      console.log(' [EXISTS] Student user already exists: student@campus.edu');
    }

    // 3. Seed or find Student 2
    let student2 = await User.findOne({ email: 'priya.verma@campus.edu' });
    if (!student2) {
      const studentPasswordHash = await User.hashPassword('Student@123456');
      student2 = await User.create({
        name: 'Priya Verma',
        email: 'priya.verma@campus.edu',
        studentId: 'EE-2026-088',
        department: 'Electrical Engineering',
        passwordHash: studentPasswordHash,
        role: 'student',
        phone: '+91 98222 33445',
      });
      console.log(' [CREATED] Student user created: priya.verma@campus.edu / Student@123456');
    }

    // 4. Seed sample complaints if none exist
    const complaintsCount = await Complaint.countDocuments();
    if (complaintsCount === 0) {
      console.log('[SEED] Seeding realistic sample complaints for demo...');

      const sampleComplaints = [
        {
          complaintNumber: 'CMP-2026-10482',
          title: 'Defective Projector and HDMI Port in Lecture Hall 302',
          description:
            'The main ceiling projector flickers constantly with a magenta tint and disconnects every 5 minutes during lectures. Prof. Mehta requested an urgent fix as presentations cannot proceed.',
          category: 'Classroom',
          location: 'Academic Block B',
          roomNumber: 'Room 302',
          priority: 'High',
          status: 'In Progress',
          student: student1._id,
          assignedDepartment: 'Audio-Visual & IT Services',
          assignedTo: 'Vikram Joshi (Senior AV Tech)',
          adminRemarks: 'Spare HDMI interface board ordered. Tech team assigned for inspection.',
          statusHistory: [
            {
              previousStatus: null,
              newStatus: 'Pending',
              timestamp: new Date(Date.now() - 48 * 3600 * 1000),
              updatedBy: student1._id,
              updatedByName: student1.name,
              remarks: 'Complaint registered by student',
            },
            {
              previousStatus: 'Pending',
              newStatus: 'In Progress',
              timestamp: new Date(Date.now() - 24 * 3600 * 1000),
              updatedBy: admin._id,
              updatedByName: `${admin.name} (Admin)`,
              remarks: 'Assigned to IT AV Team. Replacement connector in progress.',
            },
          ],
        },
        {
          complaintNumber: 'CMP-2026-20914',
          title: 'High Pressure Water Pipe Leakage in 2nd Floor Washroom',
          description:
            'Continuous water leakage from pipe joint under basin #3. Water is accumulating near the washroom entrance, creating a slipping hazard.',
          category: 'Washroom',
          location: 'Engineering Complex - South Wing',
          roomNumber: 'Floor 2 Washroom',
          priority: 'High',
          status: 'Resolved',
          student: student1._id,
          assignedDepartment: 'Plumbing & Sanitation',
          assignedTo: 'Manoj Kumar (Chief Plumber)',
          adminRemarks: 'Washer valve replaced and sealant applied. Cleanliness team disinfected area.',
          resolutionNotes: 'Pipe joint replaced with reinforced PVC fitting. Tested under pressure.',
          resolvedAt: new Date(Date.now() - 4 * 3600 * 1000),
          statusHistory: [
            {
              previousStatus: null,
              newStatus: 'Pending',
              timestamp: new Date(Date.now() - 36 * 3600 * 1000),
              updatedBy: student1._id,
              updatedByName: student1.name,
              remarks: 'Complaint registered by student',
            },
            {
              previousStatus: 'Pending',
              newStatus: 'In Progress',
              timestamp: new Date(Date.now() - 18 * 3600 * 1000),
              updatedBy: admin._id,
              updatedByName: `${admin.name} (Admin)`,
              remarks: 'Plumbing team dispatched on priority.',
            },
            {
              previousStatus: 'In Progress',
              newStatus: 'Resolved',
              timestamp: new Date(Date.now() - 4 * 3600 * 1000),
              updatedBy: admin._id,
              updatedByName: `${admin.name} (Admin)`,
              remarks: 'Valve replaced and verified dry.',
            },
          ],
        },
        {
          complaintNumber: 'CMP-2026-31057',
          title: 'No Wi-Fi Connectivity and Frequent Packet Drops in Library 3rd Floor',
          description:
            'The access point "Campus_Secure_AP3_Lib" is constantly dropping connections. Over 40 students studying for exams are unable to access research journals.',
          category: 'Internet / Wi-Fi',
          location: 'Central Library',
          roomNumber: '3rd Floor Quiet Zone',
          priority: 'Medium',
          status: 'Pending',
          student: student1._id,
          assignedDepartment: 'Network Infrastructure',
          statusHistory: [
            {
              previousStatus: null,
              newStatus: 'Pending',
              timestamp: new Date(Date.now() - 2 * 3600 * 1000),
              updatedBy: student1._id,
              updatedByName: student1.name,
              remarks: 'Complaint registered by student',
            },
          ],
        },
        {
          complaintNumber: 'CMP-2026-44120',
          title: 'Exposed Electrical Wiring near Laboratory Power Distribution Panel',
          description:
            'Noticeable insulation wear with open wires exposed next to digital electronics workbench #8. Sparks observed when heavy equipment is powered on.',
          category: 'Electricity',
          location: 'Electronics Block',
          roomNumber: 'Lab 104',
          priority: 'High',
          status: 'In Progress',
          student: student2 ? student2._id : student1._id,
          assignedDepartment: 'Electrical Maintenance',
          assignedTo: 'Rajesh Sharma',
          adminRemarks: 'Sub-breaker isolated. Electrician rewiring conduit.',
          statusHistory: [
            {
              previousStatus: null,
              newStatus: 'Pending',
              timestamp: new Date(Date.now() - 12 * 3600 * 1000),
              updatedBy: student2 ? student2._id : student1._id,
              updatedByName: student2 ? student2.name : student1.name,
              remarks: 'Urgent hazard reported',
            },
            {
              previousStatus: 'Pending',
              newStatus: 'In Progress',
              timestamp: new Date(Date.now() - 8 * 3600 * 1000),
              updatedBy: admin._id,
              updatedByName: `${admin.name} (Admin)`,
              remarks: 'Safety protocol activated. Inspection ongoing.',
            },
          ],
        },
      ];

      await Complaint.insertMany(sampleComplaints);
      console.log(` [CREATED] Seeded ${sampleComplaints.length} realistic complaints.`);
    }

    console.log('\n======================================================');
    console.log(' SEED COMPLETED SUCCESSFULLY!');
    console.log(' Demo Administrator:');
    console.log('   Email:    admin@campus.edu');
    console.log('   Password: Admin@123456');
    console.log(' Demo Student:');
    console.log('   Email:    student@campus.edu');
    console.log('   Password: Student@123456');
    console.log('======================================================\n');

    await mongoose.connection.close();
    process.exit(0);
  } catch (error) {
    console.error('[SEED ERROR] Failed:', error);
    process.exit(1);
  }
};

seedData();
