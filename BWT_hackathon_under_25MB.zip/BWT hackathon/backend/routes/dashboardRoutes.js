const express = require('express');
const router = express.Router();
const {
  getStudentDashboard,
  getAdminDashboard,
} = require('../controllers/dashboardController');
const { protect, adminOnly } = require('../middleware/auth');

router.use(protect);

router.get('/student', getStudentDashboard);
router.get('/admin', adminOnly, getAdminDashboard);

module.exports = router;
