const express = require('express');
const router = express.Router();
const {
  createComplaint,
  getComplaints,
  getComplaintById,
  updateComplaintStatus,
  updateComplaint,
  deleteComplaint,
} = require('../controllers/complaintController');
const { protect, adminOnly } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.use(protect);

router
  .route('/')
  .post(upload.single('attachment'), createComplaint)
  .get(getComplaints);

router
  .route('/:id')
  .get(getComplaintById)
  .patch(updateComplaint)
  .delete(deleteComplaint);

router.patch('/:id/status', adminOnly, updateComplaintStatus);

module.exports = router;
