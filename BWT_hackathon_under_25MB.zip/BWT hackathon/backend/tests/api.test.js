const request = require('supertest');
const mongoose = require('mongoose');
require('dotenv').config();

const { app } = require('../server');

let studentToken = '';
let studentUser = null;
let otherStudentToken = '';
let adminToken = '';
let testComplaintId = '';
let testComplaintNumber = '';

const testRunner = async () => {
  console.log('\n======================================================');
  console.log(' RUNNING AUTOMATED BACKEND API VERIFICATION SUITE');
  console.log('======================================================\n');

  let passed = 0;
  let failed = 0;

  const assert = (condition, name) => {
    if (condition) {
      console.log(`   [PASS] ${name}`);
      passed++;
    } else {
      console.error(` ❌ [FAIL] ${name}`);
      failed++;
    }
  };

  try {
    // 0. Ensure Mongoose connection is established
    if (mongoose.connection.readyState === 0) {
      await mongoose.connect(
        process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/campus_complaints'
      );
    }

    // 1. Health check endpoint
    const healthRes = await request(app).get('/api/health');
    assert(
      healthRes.status === 200 && healthRes.body.status === 'ok' && healthRes.body.database === 'connected',
      'Health endpoint GET /api/health returns 200 OK with database connected'
    );

    // 2. Student registration
    const uniqueEmail = `test.student.${Date.now()}@campus.edu`;
    const regRes = await request(app).post('/api/auth/register').send({
      name: 'Test Student Automated',
      email: uniqueEmail,
      studentId: `TEST-${Date.now().toString().slice(-4)}`,
      department: 'Information Technology',
      password: 'Password@123',
      confirmPassword: 'Password@123',
      phone: '9876543210',
    });
    assert(
      regRes.status === 201 && regRes.body.success === true && regRes.body.token,
      'Student registration POST /api/auth/register succeeds and issues JWT token'
    );
    studentToken = regRes.body.token;
    studentUser = regRes.body.user;

    // 3. Duplicate email registration rejection
    const dupRes = await request(app).post('/api/auth/register').send({
      name: 'Duplicate Student',
      email: uniqueEmail,
      department: 'Civil Engineering',
      password: 'Password@123',
    });
    assert(
      dupRes.status === 400 && dupRes.body.success === false,
      'Duplicate email registration is rejected with 400 Bad Request'
    );

    // 4. Login with correct credentials
    const loginRes = await request(app).post('/api/auth/login').send({
      email: uniqueEmail,
      password: 'Password@123',
    });
    assert(
      loginRes.status === 200 && loginRes.body.success === true && loginRes.body.token,
      'Login POST /api/auth/login succeeds with correct credentials'
    );

    // 5. Login with incorrect credentials rejected
    const badLoginRes = await request(app).post('/api/auth/login').send({
      email: uniqueEmail,
      password: 'WrongPassword999',
    });
    assert(
      badLoginRes.status === 401 && badLoginRes.body.success === false,
      'Login with incorrect password is rejected with 401 Unauthorized'
    );

    // 6. Admin login
    const adminLoginRes = await request(app).post('/api/auth/login').send({
      email: 'admin@campus.edu',
      password: 'Admin@123456',
    });
    assert(
      adminLoginRes.status === 200 && adminLoginRes.body.user.role === 'admin',
      'Administrator logs in and receives verified admin role token'
    );
    adminToken = adminLoginRes.body.token;

    // Register second student to test cross-student isolation
    const otherStudentEmail = `other.student.${Date.now()}@campus.edu`;
    const otherRegRes = await request(app).post('/api/auth/register').send({
      name: 'Other Student',
      email: otherStudentEmail,
      department: 'Mechanical',
      password: 'Password@123',
    });
    otherStudentToken = otherRegRes.body.token;

    // 7. Student creates a complaint
    const complaintRes = await request(app)
      .post('/api/complaints')
      .set('Authorization', `Bearer ${studentToken}`)
      .send({
        title: 'Flickering lights in Room 204',
        description: 'Fluorescent tubes in rows 2 and 3 are vibrating and buzzing loudly.',
        category: 'Electricity',
        location: 'Science Building',
        roomNumber: 'Room 204',
        priority: 'Medium',
      });
    assert(
      complaintRes.status === 201 &&
        complaintRes.body.success === true &&
        complaintRes.body.complaintNumber &&
        complaintRes.body.complaint.status === 'Pending',
      'Student creates complaint POST /api/complaints with status "Pending" and unique reference number'
    );
    testComplaintId = complaintRes.body.complaint._id;
    testComplaintNumber = complaintRes.body.complaint.complaintNumber;

    // 8. Student views own complaints
    const myComplaintsRes = await request(app)
      .get('/api/complaints')
      .set('Authorization', `Bearer ${studentToken}`);
    assert(
      myComplaintsRes.status === 200 &&
        myComplaintsRes.body.complaints.some((c) => c._id === testComplaintId),
      'Student can view their own complaints list GET /api/complaints'
    );

    // 9. Cross-student access rejection (security check)
    const unauthorizedAccessRes = await request(app)
      .get(`/api/complaints/${testComplaintId}`)
      .set('Authorization', `Bearer ${otherStudentToken}`);
    assert(
      unauthorizedAccessRes.status === 403,
      'Student is blocked with 403 Forbidden when trying to access another student\'s private complaint'
    );

    // 10. Student blocked from Admin-only APIs
    const studentBlockedFromAdminRes = await request(app)
      .get('/api/dashboard/admin')
      .set('Authorization', `Bearer ${studentToken}`);
    assert(
      studentBlockedFromAdminRes.status === 403,
      'Student is blocked with 403 Forbidden from accessing Admin dashboard GET /api/dashboard/admin'
    );

    // 11. Administrator views all complaints
    const adminComplaintsRes = await request(app)
      .get('/api/complaints')
      .set('Authorization', `Bearer ${adminToken}`);
    assert(
      adminComplaintsRes.status === 200 && adminComplaintsRes.body.total > 0,
      'Administrator can view all complaints system-wide'
    );

    // 12. Administrator updates complaint status
    const updateStatusRes = await request(app)
      .patch(`/api/complaints/${testComplaintId}/status`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({
        status: 'In Progress',
        adminRemarks: 'Assigned electrician team to replace tube ballasts.',
        assignedDepartment: 'Electrical Maintenance',
        assignedTo: 'Suresh Electrician',
      });
    assert(
      updateStatusRes.status === 200 &&
        updateStatusRes.body.complaint.status === 'In Progress' &&
        updateStatusRes.body.complaint.statusHistory.length >= 2,
      'Administrator updates status to "In Progress" and statusHistory logs the transition'
    );

    // 13. Admin resolves complaint
    const resolveStatusRes = await request(app)
      .patch(`/api/complaints/${testComplaintId}/status`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({
        status: 'Resolved',
        resolutionNotes: 'Ballast and tubes replaced, verified working safely.',
      });
    assert(
      resolveStatusRes.status === 200 &&
        resolveStatusRes.body.complaint.status === 'Resolved' &&
        resolveStatusRes.body.complaint.resolvedAt !== null,
      'Administrator marks complaint "Resolved" and resolvedAt timestamp is saved'
    );

    // 14. Student Dashboard returns consistent counts
    const studentDashRes = await request(app)
      .get('/api/dashboard/student')
      .set('Authorization', `Bearer ${studentToken}`);
    assert(
      studentDashRes.status === 200 &&
        studentDashRes.body.data.stats.total >= 1 &&
        studentDashRes.body.data.stats.resolved >= 1,
      'Student dashboard GET /api/dashboard/student reflects live database counts'
    );

    // 15. Admin Dashboard returns system metrics
    const adminDashRes = await request(app)
      .get('/api/dashboard/admin')
      .set('Authorization', `Bearer ${adminToken}`);
    assert(
      adminDashRes.status === 200 &&
        adminDashRes.body.data.stats.total >= 1 &&
        Array.isArray(adminDashRes.body.data.categoryStats),
      'Admin dashboard GET /api/dashboard/admin returns aggregated category & priority stats'
    );

    // 16. Profile view and edit
    const profileRes = await request(app)
      .get('/api/users/me')
      .set('Authorization', `Bearer ${studentToken}`);
    assert(
      profileRes.status === 200 && profileRes.body.user.email === uniqueEmail,
      'Profile endpoint GET /api/users/me returns authenticated student data'
    );

    const updateProfileRes = await request(app)
      .patch('/api/users/me')
      .set('Authorization', `Bearer ${studentToken}`)
      .send({
        name: 'Updated Student Name',
        phone: '9988776655',
        role: 'admin', // Malicious attempt to elevate role
      });
    assert(
      updateProfileRes.status === 200 &&
        updateProfileRes.body.user.name === 'Updated Student Name' &&
        updateProfileRes.body.user.role === 'student',
      'Profile update allows updating info while strictly blocking role escalation'
    );

    console.log('\n======================================================');
    console.log(` RESULTS: ${passed} Passed, ${failed} Failed`);
    console.log('======================================================\n');

    await mongoose.connection.close();
    process.exit(failed === 0 ? 0 : 1);
  } catch (error) {
    console.error('Test Suite Exception:', error);
    if (mongoose.connection.readyState !== 0) {
      await mongoose.connection.close();
    }
    process.exit(1);
  }
};

testRunner();
