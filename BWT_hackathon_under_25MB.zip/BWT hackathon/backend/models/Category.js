const mongoose = require('mongoose');

const categorySchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    description: {
      type: String,
      default: '',
    },
    defaultDepartment: {
      type: String,
      default: 'General Maintenance',
    },
    iconName: {
      type: String,
      default: 'AlertCircle',
    },
    slaHours: {
      type: Number,
      default: 48,
    },
  },
  { timestamps: true }
);

const Category = mongoose.model('Category', categorySchema);
module.exports = Category;
