const mongoose = require('mongoose');

const statusHistorySchema = new mongoose.Schema(
  {
    previousStatus: {
      type: String,
      default: null,
    },
    newStatus: {
      type: String,
      required: true,
      enum: ['Pending', 'In Progress', 'Resolved', 'Rejected'],
    },
    timestamp: {
      type: Date,
      default: Date.now,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    updatedByName: {
      type: String,
      default: 'System',
    },
    remarks: {
      type: String,
      default: '',
    },
  },
  { _id: true }
);

const complaintSchema = new mongoose.Schema(
  {
    complaintNumber: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    title: {
      type: String,
      required: [true, 'Please provide complaint title'],
      trim: true,
      maxlength: [150, 'Title cannot exceed 150 characters'],
    },
    description: {
      type: String,
      required: [true, 'Please provide detailed complaint description'],
      trim: true,
      maxlength: [3000, 'Description cannot exceed 3000 characters'],
    },
    category: {
      type: String,
      required: [true, 'Please select a complaint category'],
      enum: {
        values: [
          'Electricity',
          'Water Supply',
          'Cleanliness',
          'Washroom',
          'Classroom',
          'Laboratory',
          'Furniture',
          'Internet / Wi-Fi',
          'Safety and Security',
          'Other',
        ],
        message: '{VALUE} is not a valid category',
      },
    },
    location: {
      type: String,
      required: [true, 'Please specify campus building or location'],
      trim: true,
      maxlength: [100, 'Location cannot exceed 100 characters'],
    },
    roomNumber: {
      type: String,
      trim: true,
      default: '',
      maxlength: [50, 'Room number cannot exceed 50 characters'],
    },
    priority: {
      type: String,
      enum: ['Low', 'Medium', 'High'],
      default: 'Medium',
    },
    status: {
      type: String,
      enum: ['Pending', 'In Progress', 'Resolved', 'Rejected'],
      default: 'Pending',
      index: true,
    },
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    assignedDepartment: {
      type: String,
      trim: true,
      default: 'General Maintenance',
    },
    assignedTo: {
      type: String,
      trim: true,
      default: '',
    },
    adminRemarks: {
      type: String,
      trim: true,
      default: '',
    },
    resolutionNotes: {
      type: String,
      trim: true,
      default: '',
    },
    attachmentUrl: {
      type: String,
      default: '',
    },
    statusHistory: [statusHistorySchema],
    resolvedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

// Helpful compound indexes for query performance
complaintSchema.index({ student: 1, createdAt: -1 });
complaintSchema.index({ status: 1, category: 1 });
complaintSchema.index({ createdAt: -1 });

const Complaint = mongoose.model('Complaint', complaintSchema);
module.exports = Complaint;
