const mongoose = require('mongoose');

const connectDB = async () => {
  const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/campus_complaints';
  try {
    console.log(`[DB] Connecting to MongoDB at: ${uri.replace(/\/\/[^:]+:[^@]+@/, '//***:***@')} ...`);
    const conn = await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 5000,
    });
    console.log(`[DB] MongoDB Connected Successfully: ${conn.connection.host}/${conn.connection.name}`);
    return conn;
  } catch (error) {
    console.error('\n======================================================');
    console.error('[DB ERROR] Fatal: Could not connect to MongoDB database.');
    console.error(`Reason: ${error.message}`);
    console.error('Troubleshooting Tips:');
    console.error(' 1. Check if local MongoDB is running: Start the service "MongoDB"');
    console.error(' 2. If using MongoDB Atlas, verify your MONGODB_URI in backend/.env');
    console.error(' 3. Ensure your IP address is whitelisted on MongoDB Atlas Network Access');
    console.error('======================================================\n');
    process.exit(1);
  }
};

module.exports = connectDB;
