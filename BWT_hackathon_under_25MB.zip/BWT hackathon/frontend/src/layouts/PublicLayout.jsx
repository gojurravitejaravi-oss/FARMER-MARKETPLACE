import React from 'react';
import { Outlet, Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { ShieldAlert, Heart, Mail, Phone, ExternalLink } from 'lucide-react';

const PublicLayout = () => {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <Navbar />

      <main className="flex-1">
        <Outlet />
      </main>

      {/* Professional Footer */}
      <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 pt-12 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-12 border-b border-slate-800">
            {/* Col 1: Brand */}
            <div className="space-y-3 md:col-span-1">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <span className="text-white font-extrabold text-lg tracking-tight">
                  Campus<span className="text-teal-400">Resolve</span>
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Centralized campus complaint lodging, automated routing, and transparent status tracking system built for modern university environments.
              </p>
              <div className="text-xs text-teal-400 font-semibold tracking-wide uppercase">
                Tagline: Report. Track. Resolve.
              </div>
            </div>

            {/* Col 2: Quick Links */}
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
                Quick Access
              </h4>
              <ul className="space-y-2 text-xs">
                <li>
                  <Link to="/login" className="hover:text-teal-400 transition-colors">
                    Student Login
                  </Link>
                </li>
                <li>
                  <Link to="/register" className="hover:text-teal-400 transition-colors">
                    Register New Student
                  </Link>
                </li>
                <li>
                  <Link to="/login" className="hover:text-teal-400 transition-colors">
                    Administrator Portal
                  </Link>
                </li>
                <li>
                  <a href="#how-it-works" className="hover:text-teal-400 transition-colors">
                    Resolution Workflow
                  </a>
                </li>
              </ul>
            </div>

            {/* Col 3: Key Complaint Categories */}
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
                Core Domains
              </h4>
              <ul className="space-y-2 text-xs">
                <li className="hover:text-slate-300">Electricity & Power Systems</li>
                <li className="hover:text-slate-300">Water Supply & Sanitation</li>
                <li className="hover:text-slate-300">Classroom & Lab Facilities</li>
                <li className="hover:text-slate-300">Campus Wi-Fi & IT Networks</li>
                <li className="hover:text-slate-300">Security & Infrastructure</li>
              </ul>
            </div>

            {/* Col 4: Campus Support & Demo Info */}
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
                Emergency & Support
              </h4>
              <div className="space-y-2 text-xs">
                <p className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-teal-400" />
                  support@campus.edu
                </p>
                <p className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-teal-400" />
                  +91 (0) 11 2345 6789
                </p>
                <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700/80 mt-3 text-[11px]">
                  <span className="font-semibold text-teal-300 block mb-0.5">Demo Accounts Available</span>
                  <span>Use quick-fill buttons on the login page for instant admin and student evaluation.</span>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
            <p>© {new Date().getFullYear()} Campus Complaint Management System. All rights reserved.</p>
            <p className="flex items-center gap-1">
              Engineered with <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 inline" /> for BWT Hackathon
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default PublicLayout;
