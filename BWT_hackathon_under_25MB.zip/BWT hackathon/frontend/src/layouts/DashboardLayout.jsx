import React, { useState } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import { useAuth } from '../context/AuthContext';
import { Menu, PlusCircle, Bell, Shield, User } from 'lucide-react';

const DashboardLayout = () => {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const { user, isAdmin } = useAuth();
  const location = useLocation();

  // Simple title generator based on path
  const getHeaderTitle = () => {
    const path = location.pathname;
    if (path.includes('/complaints/new')) return 'Lodge New Complaint';
    if (path.includes('/complaints/') && !path.endsWith('/complaints')) return 'Complaint Details & Tracking';
    if (path.includes('/student/complaints')) return 'My Complaints Directory';
    if (path.includes('/admin/complaints')) return 'Campus Complaints Management';
    if (path.includes('/profile')) return 'My Profile';
    if (path.includes('/admin/dashboard')) return 'Administrative Control Center';
    return 'Student Dashboard';
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <Sidebar
        isMobileOpen={mobileSidebarOpen}
        closeMobileSidebar={() => setMobileSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 md:pl-64">
        {/* Top Navbar */}
        <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200/80 h-16 flex items-center justify-between px-4 sm:px-6 lg:px-8 shadow-2xs">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="p-2 -ml-2 rounded-xl text-slate-700 hover:bg-slate-100 md:hidden"
              aria-label="Open sidebar"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="text-base sm:text-lg font-bold text-slate-900 truncate">
              {getHeaderTitle()}
            </h1>
          </div>

          <div className="flex items-center gap-3">
            {!isAdmin && (
              <Link
                to="/student/complaints/new"
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-teal-600 hover:bg-teal-700 text-white shadow-xs transition-all"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                Submit Issue
              </Link>
            )}

            <div className="flex items-center gap-2 pl-3 border-l border-slate-200">
              <span className="hidden sm:inline-block text-xs font-medium text-slate-600">
                {user?.name}
              </span>
              <div className="w-8 h-8 rounded-full bg-slate-900 text-teal-300 flex items-center justify-center font-bold text-xs shadow-xs">
                {user?.name?.charAt(0) || 'U'}
              </div>
            </div>
          </div>
        </header>

        {/* Dynamic Page Container */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
