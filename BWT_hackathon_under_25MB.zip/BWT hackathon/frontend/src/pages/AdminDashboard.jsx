import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import StatCard from '../components/StatCard';
import StatusBadge from '../components/StatusBadge';
import PriorityBadge from '../components/PriorityBadge';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { useToast } from '../context/ToastContext';
import {
  FileText,
  Clock,
  RefreshCw,
  CheckCircle2,
  XCircle,
  Users,
  Search,
  Filter,
  ArrowRight,
  AlertTriangle,
  Building,
  Calendar,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  BarChart3,
  PieChart as PieIcon,
  Send,
  X,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
  PieChart,
  Pie,
  Legend,
} from 'recharts';

const AdminDashboard = () => {
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState({
    stats: { total: 0, pending: 0, inProgress: 0, resolved: 0, rejected: 0, totalStudents: 0 },
    categoryStats: [],
    priorityStats: [],
    recentComplaints: [],
    attentionRequired: [],
  });

  // Table management state
  const [complaints, setComplaints] = useState([]);
  const [tableLoading, setTableLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalRecords, setTotalRecords] = useState(0);

  // Quick Status Update Modal state
  const [activeModalComplaint, setActiveModalComplaint] = useState(null);
  const [newStatus, setNewStatus] = useState('In Progress');
  const [adminRemarks, setAdminRemarks] = useState('');
  const [assignedDept, setAssignedDept] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  const toast = useToast();

  const categories = [
    'Electricity',
    'Water Supply',
    'Cleanliness',
    'Washroom',
    'Classroom',
    'Laboratory',
    'Furniture',
    'Internet / Wi-Fi',
    'Safety and Security',
    'Other',
  ];

  const fetchDashboardStats = async () => {
    try {
      setLoading(true);
      const res = await api.get('/dashboard/admin');
      if (res.data.success) {
        setDashboardData(res.data.data);
      }
    } catch (err) {
      console.error('Failed to load admin stats:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchComplaintsTable = async () => {
    try {
      setTableLoading(true);
      const params = {
        page,
        limit: 10,
        sort: '-createdAt',
      };
      if (search.trim()) params.search = search.trim();
      if (statusFilter !== 'all') params.status = statusFilter;
      if (categoryFilter !== 'all') params.category = categoryFilter;
      if (priorityFilter !== 'all') params.priority = priorityFilter;

      const res = await api.get('/complaints', { params });
      if (res.data.success) {
        setComplaints(res.data.complaints);
        setTotalPages(res.data.totalPages);
        setTotalRecords(res.data.total);
      }
    } catch (err) {
      console.error('Failed to load complaints table:', err);
    } finally {
      setTableLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  useEffect(() => {
    fetchComplaintsTable();
  }, [page, statusFilter, categoryFilter, priorityFilter]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    setPage(1);
    fetchComplaintsTable();
  };

  const openStatusModal = (complaint) => {
    setActiveModalComplaint(complaint);
    setNewStatus(complaint.status);
    setAssignedDept(complaint.assignedDepartment || '');
    setAdminRemarks('');
  };

  const closeStatusModal = () => {
    setActiveModalComplaint(null);
  };

  const handleStatusSubmit = async (e) => {
    e.preventDefault();
    if (!activeModalComplaint) return;

    try {
      setIsUpdating(true);
      const res = await api.patch(`/complaints/${activeModalComplaint._id}/status`, {
        status: newStatus,
        adminRemarks: adminRemarks.trim(),
        assignedDepartment: assignedDept.trim(),
      });

      if (res.data.success) {
        toast.success(`Complaint ${activeModalComplaint.complaintNumber} updated to ${newStatus}`);
        closeStatusModal();
        fetchComplaintsTable();
        fetchDashboardStats();
      }
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update status');
    } finally {
      setIsUpdating(false);
    }
  };

  if (loading) {
    return <LoadingSpinner text="Connecting to MongoDB administrative center..." />;
  }

  const { stats, categoryStats, priorityStats, attentionRequired } = dashboardData;

  const COLORS = ['#0d9488', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#64748b'];

  return (
    <div className="space-y-8 animate-fade-in pb-16">
      {/* Header Banner */}
      <div className="bg-slate-900 rounded-3xl p-6 sm:p-8 text-white flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-md">
        <div className="space-y-1.5">
          <span className="text-teal-400 font-bold uppercase tracking-widest text-[11px] block">
            Central Facilities Command
          </span>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
            Campus Administrator Dashboard
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Real-time grievance monitoring, departmental resolution dispatch, and student SLA metrics.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              fetchDashboardStats();
              fetchComplaintsTable();
              toast.info('Dashboard synced with MongoDB');
            }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 font-bold text-xs border border-slate-700 transition-colors cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Refresh Live Data
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <StatCard
          title="Total Complaints"
          value={stats.total}
          icon={FileText}
          color="blue"
          subtitle="All records"
        />
        <StatCard
          title="Pending Action"
          value={stats.pending}
          icon={Clock}
          color="amber"
          subtitle="Requires review"
        />
        <StatCard
          title="In Progress"
          value={stats.inProgress}
          icon={RefreshCw}
          color="teal"
          subtitle="Team dispatched"
        />
        <StatCard
          title="Resolved"
          value={stats.resolved}
          icon={CheckCircle2}
          color="emerald"
          subtitle="Closed successfully"
        />
        <StatCard
          title="Rejected"
          value={stats.rejected}
          icon={XCircle}
          color="rose"
          subtitle="Closure remarks"
        />
        <StatCard
          title="Students"
          value={stats.totalStudents}
          icon={Users}
          color="indigo"
          subtitle="Registered accounts"
        />
      </div>

      {/* Attention Required Banner if high-priority pending */}
      {attentionRequired && attentionRequired.length > 0 && (
        <div className="bg-rose-50/70 border border-rose-200 rounded-3xl p-5 sm:p-6 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-rose-900 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              Complaints Requiring Immediate Attention ({attentionRequired.length})
            </h3>
            <span className="text-xs text-rose-700 font-semibold">High Priority & Escalations</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {attentionRequired.slice(0, 3).map((item) => (
              <div
                key={item._id}
                className="bg-white p-3.5 rounded-xl border border-rose-100 shadow-2xs text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-slate-700">{item.complaintNumber}</span>
                  <PriorityBadge priority={item.priority} />
                </div>
                <p className="font-bold text-slate-900 truncate">{item.title}</p>
                <p className="text-slate-500 text-[11px] truncate">
                  {item.location} • By {item.student?.name || 'Student'}
                </p>
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <StatusBadge status={item.status} />
                  <Link
                    to={`/student/complaints/${item._id}`}
                    className="text-teal-700 font-bold hover:underline"
                  >
                    Resolve →
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Visual Analytics Grid (Recharts) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Category Breakdown Bar Chart */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-teal-600" />
              Complaints by Category
            </h3>
            <span className="text-xs text-slate-400 font-medium">Distribution</span>
          </div>

          <div className="h-64 w-full">
            {categoryStats.length === 0 ? (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                No category data available
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryStats} margin={{ top: 10, right: 10, left: -20, bottom: 25 }}>
                  <XAxis
                    dataKey="category"
                    tick={{ fontSize: 10 }}
                    interval={0}
                    angle={-25}
                    textAnchor="end"
                  />
                  <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderRadius: '12px',
                      color: '#fff',
                      fontSize: '12px',
                      border: 'none',
                    }}
                  />
                  <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                    {categoryStats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Priority Breakdown Pie Chart */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-teal-600" />
              Priority Urgency Breakdown
            </h3>
            <span className="text-xs text-slate-400 font-medium">Triage Level</span>
          </div>

          <div className="h-64 w-full">
            {priorityStats.length === 0 ? (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                No priority data available
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={priorityStats}
                    dataKey="count"
                    nameKey="priority"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    innerRadius={45}
                    paddingAngle={4}
                    label={({ priority, count }) => `${priority}: ${count}`}
                  >
                    {priorityStats.map((entry, index) => {
                      let color = '#3b82f6';
                      if (entry.priority === 'High') color = '#ef4444';
                      if (entry.priority === 'Medium') color = '#f59e0b';
                      if (entry.priority === 'Low') color = '#10b981';
                      return <Cell key={`pie-cell-${index}`} fill={color} />;
                    })}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderRadius: '12px',
                      color: '#fff',
                      fontSize: '12px',
                      border: 'none',
                    }}
                  />
                  <Legend verticalAlign="bottom" height={36} iconSize={8} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      {/* Comprehensive Complaints Management Table */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm overflow-hidden space-y-4 p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-extrabold text-slate-900">
              Campus Complaints Directory & Action Console
            </h3>
            <p className="text-xs text-slate-500">
              Showing {complaints.length} of {totalRecords} total campus records from MongoDB
            </p>
          </div>
        </div>

        {/* Filter controls */}
        <div className="space-y-3 pt-2">
          <form onSubmit={handleSearchSubmit} className="flex gap-2">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Search className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search ticket number, title, student, location..."
                className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-purple-500 text-xs"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold transition-colors cursor-pointer"
            >
              Search
            </button>
          </form>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Status</label>
              <select
                value={statusFilter}
                onChange={(e) => {
                  setStatusFilter(e.target.value);
                  setPage(1);
                }}
                className="w-full p-2 rounded-xl border border-slate-200 bg-slate-50 text-xs font-medium"
              >
                <option value="all">All Statuses</option>
                <option value="Pending">Pending</option>
                <option value="In Progress">In Progress</option>
                <option value="Resolved">Resolved</option>
                <option value="Rejected">Rejected</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Category</label>
              <select
                value={categoryFilter}
                onChange={(e) => {
                  setCategoryFilter(e.target.value);
                  setPage(1);
                }}
                className="w-full p-2 rounded-xl border border-slate-200 bg-slate-50 text-xs font-medium"
              >
                <option value="all">All Categories</option>
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Priority</label>
              <select
                value={priorityFilter}
                onChange={(e) => {
                  setPriorityFilter(e.target.value);
                  setPage(1);
                }}
                className="w-full p-2 rounded-xl border border-slate-200 bg-slate-50 text-xs font-medium"
              >
                <option value="all">All Priorities</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>
          </div>
        </div>

        {/* Responsive Table */}
        <div className="overflow-x-auto">
          {tableLoading ? (
            <div className="py-12">
              <LoadingSpinner text="Refreshing complaints registry..." />
            </div>
          ) : complaints.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              No matching records found.
            </div>
          ) : (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold uppercase tracking-wider text-[10px] border-y border-slate-200">
                <tr>
                  <th className="py-3 px-3">Ticket ID</th>
                  <th className="py-3 px-3">Student</th>
                  <th className="py-3 px-3">Title & Issue</th>
                  <th className="py-3 px-3">Category</th>
                  <th className="py-3 px-3">Location</th>
                  <th className="py-3 px-3">Priority</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-3">Date</th>
                  <th className="py-3 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {complaints.map((c) => (
                  <tr key={c._id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3 font-mono font-bold text-teal-800">
                      {c.complaintNumber}
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-bold text-slate-900">{c.student?.name || 'Student'}</div>
                      <div className="text-[10px] text-slate-400">{c.student?.department}</div>
                    </td>
                    <td className="py-3 px-3 max-w-xs">
                      <div className="font-semibold text-slate-900 truncate">{c.title}</div>
                      <div className="text-[10px] text-slate-400 truncate">{c.description}</div>
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[11px]">
                        {c.category}
                      </span>
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap text-slate-600">
                      {c.location}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      <PriorityBadge priority={c.priority} />
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      <StatusBadge status={c.status} />
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap text-slate-400 text-[11px]">
                      {new Date(c.createdAt).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap text-right space-x-1.5">
                      <button
                        onClick={() => openStatusModal(c)}
                        className="px-2.5 py-1 rounded-lg bg-purple-50 text-purple-700 border border-purple-200 hover:bg-purple-100 text-[11px] font-bold cursor-pointer"
                      >
                        Status
                      </button>
                      <Link
                        to={`/student/complaints/${c._id}`}
                        className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 text-[11px] font-bold inline-block"
                      >
                        Details
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between pt-4 border-t border-slate-100 text-xs">
            <span className="text-slate-500">
              Page <span className="font-bold">{page}</span> of{' '}
              <span className="font-bold">{totalPages}</span>
            </span>
            <div className="flex items-center gap-2">
              <button
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                disabled={page >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Quick Status Update Modal */}
      {activeModalComplaint && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <span className="font-mono text-xs font-bold text-teal-800">
                  {activeModalComplaint.complaintNumber}
                </span>
                <h3 className="text-base font-extrabold text-slate-900">
                  Update Complaint Status
                </h3>
              </div>
              <button
                onClick={closeStatusModal}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleStatusSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 font-bold uppercase tracking-wider mb-1">
                  Target Status *
                </label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 bg-white font-bold text-slate-800"
                >
                  <option value="Pending">Pending</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Resolved">Resolved</option>
                  <option value="Rejected">Rejected</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-bold uppercase tracking-wider mb-1">
                  Responsible Department
                </label>
                <input
                  type="text"
                  value={assignedDept}
                  onChange={(e) => setAssignedDept(e.target.value)}
                  placeholder="e.g. Electrical / Water Maintenance"
                  className="w-full p-2.5 rounded-xl border border-slate-300"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold uppercase tracking-wider mb-1">
                  Administrator Remarks / Action Note
                </label>
                <textarea
                  rows={3}
                  value={adminRemarks}
                  onChange={(e) => setAdminRemarks(e.target.value)}
                  placeholder="Describe parts replaced, contractor dispatched, or justification for rejection..."
                  className="w-full p-2.5 rounded-xl border border-slate-300"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={closeStatusModal}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isUpdating}
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold cursor-pointer disabled:opacity-50"
                >
                  {isUpdating ? 'Updating...' : 'Commit Status'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
