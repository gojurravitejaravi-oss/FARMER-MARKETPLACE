import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import StatCard from '../components/StatCard';
import StatusBadge from '../components/StatusBadge';
import PriorityBadge from '../components/PriorityBadge';
import { LoadingSpinner } from '../components/LoadingSpinner';
import {
  FileText,
  Clock,
  RefreshCw,
  CheckCircle2,
  XCircle,
  PlusCircle,
  ArrowRight,
  MapPin,
  Calendar,
  AlertCircle,
  Activity,
} from 'lucide-react';

const StudentDashboard = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState({
    stats: { total: 0, pending: 0, inProgress: 0, resolved: 0, rejected: 0 },
    recentComplaints: [],
    recentActivities: [],
  });
  const [error, setError] = useState(null);

  const fetchDashboard = async () => {
    try {
      setLoading(true);
      const res = await api.get('/dashboard/student');
      if (res.data.success) {
        setDashboardData(res.data.data);
      }
    } catch (err) {
      console.error('Failed to load dashboard:', err);
      setError('Unable to load live dashboard statistics. Please refresh.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  if (loading) {
    return <LoadingSpinner text="Fetching your student grievance profile & records..." />;
  }

  const { stats, recentComplaints, recentActivities } = dashboardData;

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Welcome & Quick Action Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-teal-900 rounded-3xl p-6 sm:p-8 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <span className="text-teal-400 font-bold uppercase tracking-widest text-[11px] block">
              Student Grievance Dashboard
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Welcome back, {user?.name}!
            </h2>
            <p className="text-xs sm:text-sm text-slate-300">
              Department of {user?.department || 'Engineering'} • Student ID:{' '}
              <span className="font-mono text-teal-300">{user?.studentId || 'N/A'}</span>
            </p>
          </div>

          <Link
            to="/student/complaints/new"
            className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-extrabold text-sm shadow-md transition-all shrink-0"
          >
            <PlusCircle className="w-4 h-4" />
            Lodge New Complaint
          </Link>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-sm">
          {error}
        </div>
      )}

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        <StatCard
          title="Total Submitted"
          value={stats.total}
          icon={FileText}
          color="blue"
          subtitle="All-time grievances"
        />
        <StatCard
          title="Pending"
          value={stats.pending}
          icon={Clock}
          color="amber"
          subtitle="Awaiting triage"
        />
        <StatCard
          title="In Progress"
          value={stats.inProgress}
          icon={RefreshCw}
          color="teal"
          subtitle="Technician assigned"
        />
        <StatCard
          title="Resolved"
          value={stats.resolved}
          icon={CheckCircle2}
          color="emerald"
          subtitle="Fixed & verified"
        />
        <StatCard
          title="Rejected"
          value={stats.rejected}
          icon={XCircle}
          color="rose"
          subtitle="With closure reason"
        />
      </div>

      {/* Main Grid: Recent Complaints + Activity Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column (2 spans): Recent Complaints */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <FileText className="w-4 h-4 text-teal-600" />
              Recent Submissions
            </h3>
            <Link
              to="/student/complaints"
              className="text-xs font-semibold text-teal-600 hover:text-teal-700 flex items-center gap-1"
            >
              View all ({stats.total}) <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {recentComplaints.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 border border-slate-200/80 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
                <AlertCircle className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-800">No complaints lodged yet</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Found a broken light, internet issue, or washroom problem on campus? Submit a complaint to notify maintenance.
              </p>
              <Link
                to="/student/complaints/new"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-600 text-white text-xs font-bold"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                Submit Your First Issue
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {recentComplaints.map((item) => (
                <Link
                  key={item._id}
                  to={`/student/complaints/${item._id}`}
                  className="block bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 hover:border-teal-500/50 hover:shadow-sm transition-all group"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-md border border-teal-200">
                        {item.complaintNumber}
                      </span>
                      <span className="text-xs text-slate-500 font-medium">
                        {item.category}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <PriorityBadge priority={item.priority} />
                      <StatusBadge status={item.status} />
                    </div>
                  </div>

                  <h4 className="text-sm font-bold text-slate-900 group-hover:text-teal-700 transition-colors line-clamp-1">
                    {item.title}
                  </h4>

                  <p className="text-xs text-slate-500 line-clamp-2 mt-1 mb-3">
                    {item.description}
                  </p>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-100">
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        {item.location} {item.roomNumber && `(${item.roomNumber})`}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        {new Date(item.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <span className="font-semibold text-teal-600 group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                      Track <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Live Status Updates Timeline */}
        <div className="space-y-4">
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Activity className="w-4 h-4 text-teal-600" />
            Status Updates Stream
          </h3>

          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-2xs space-y-4">
            {recentActivities.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-6">
                No activity updates logged yet.
              </p>
            ) : (
              <div className="relative pl-6 space-y-5 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                {recentActivities.map((act, idx) => (
                  <div key={idx} className="relative group text-xs">
                    <div className="absolute -left-6 top-1 w-3 h-3 rounded-full bg-white border-2 border-teal-500 shadow-2xs" />
                    <div className="flex items-center justify-between gap-1 mb-0.5">
                      <span className="font-mono text-[10px] font-bold text-slate-500">
                        {act.complaintNumber}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {new Date(act.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>

                    <div className="font-semibold text-slate-800">
                      Status moved to <span className="text-teal-700 font-bold">{act.newStatus}</span>
                    </div>

                    {act.remarks && (
                      <p className="text-slate-500 italic mt-0.5 text-[11px] bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                        "{act.remarks}"
                      </p>
                    )}

                    <div className="text-[10px] text-slate-400 mt-1">
                      By {act.updatedByName || 'Admin'}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
