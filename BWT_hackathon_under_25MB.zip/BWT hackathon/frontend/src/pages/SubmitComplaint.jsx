import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import api from '../services/api';
import { useToast } from '../context/ToastContext';
import {
  PlusCircle,
  RotateCcw,
  Upload,
  CheckCircle2,
  AlertCircle,
  Building,
  Tag,
  AlignLeft,
  ArrowRight,
  ShieldAlert,
  Image as ImageIcon,
  X,
} from 'lucide-react';

const categories = [
  'Electricity',
  'Water Supply',
  'Cleanliness',
  'Washroom',
  'Classroom',
  'Laboratory',
  'Furniture',
  'Internet / Wi-Fi',
  'Safety and Security',
  'Other',
];

const locations = [
  'Academic Block A',
  'Academic Block B',
  'Central Library',
  'Science & Technology Complex',
  'Computer Science Labs Building',
  'Mechanical & Civil Workshops',
  'Student Activity Center (SAC)',
  'Main Auditorium',
  'Campus Cafeteria & Food Court',
  'Boys Hostel Block 1-4',
  'Girls Hostel Block 1-3',
  'Sports Arena & Gymnasium',
  'Administrative Tower',
  'Campus Grounds / Outdoor Pathways',
  'Other Campus Location',
];

const SubmitComplaint = () => {
  const [formData, setFormData] = useState({
    title: '',
    category: 'Electricity',
    location: 'Academic Block A',
    roomNumber: '',
    priority: 'Medium',
    description: '',
  });

  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedData, setSubmittedData] = useState(null);
  const [errorMessage, setErrorMessage] = useState('');

  const toast = useToast();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setErrorMessage('');
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error('File size cannot exceed 5MB');
        return;
      }
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

  const removeFile = () => {
    setSelectedFile(null);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
    }
  };

  const handleReset = () => {
    setFormData({
      title: '',
      category: 'Electricity',
      location: 'Academic Block A',
      roomNumber: '',
      priority: 'Medium',
      description: '',
    });
    removeFile();
    setErrorMessage('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage('');

    if (!formData.title.trim() || !formData.description.trim()) {
      setErrorMessage('Please provide a complaint title and detailed description.');
      return;
    }

    try {
      setIsSubmitting(true);

      const data = new FormData();
      data.append('title', formData.title.trim());
      data.append('category', formData.category);
      data.append('location', formData.location);
      data.append('roomNumber', formData.roomNumber.trim());
      data.append('priority', formData.priority);
      data.append('description', formData.description.trim());

      if (selectedFile) {
        data.append('attachment', selectedFile);
      }

      const res = await api.post('/complaints', data, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      if (res.data.success) {
        toast.success(`Complaint registered successfully! Reference: ${res.data.complaintNumber}`);
        setSubmittedData(res.data);
      } else {
        setErrorMessage(res.data.message || 'Failed to submit complaint.');
      }
    } catch (err) {
      console.error('Submission error:', err);
      const msg = err.response?.data?.message || 'Error saving complaint. Please try again.';
      setErrorMessage(msg);
      toast.error(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  // If successfully submitted, show success state with ticket details
  if (submittedData) {
    return (
      <div className="max-w-2xl mx-auto py-10 px-4 animate-fade-in">
        <div className="bg-white rounded-3xl p-8 sm:p-10 border border-slate-200/90 shadow-xl text-center space-y-6">
          <div className="w-16 h-16 rounded-3xl bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center shadow-lg shadow-emerald-500/10">
            <CheckCircle2 className="w-9 h-9" />
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              Complaint Lodged Successfully!
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto">
              Your grievance has been stored in MongoDB and routed to the campus facilities dispatch queue.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-teal-50/60 border border-teal-200/80 max-w-md mx-auto text-center space-y-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-teal-800">
              Unique Reference Tracking ID
            </span>
            <div className="font-mono text-2xl font-black text-teal-900 tracking-wider">
              {submittedData.complaintNumber}
            </div>
            <p className="text-[11px] text-teal-700">
              Save this reference number to monitor live updates and inspection notes.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4">
            <button
              onClick={() => {
                setSubmittedData(null);
                handleReset();
              }}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Submit Another Complaint
            </button>
            <button
              onClick={() => navigate(`/student/complaints/${submittedData.complaint._id}`)}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-md shadow-teal-600/20 transition-all cursor-pointer"
            >
              Track Live Status <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in pb-12">
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
          Lodge a Campus Facility Complaint
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Provide complete details below to help campus administrators triage and dispatch maintenance teams promptly.
        </p>
      </div>

      {errorMessage && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          {errorMessage}
        </div>
      )}

      {/* Main Submission Form */}
      <form onSubmit={handleSubmit} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-sm space-y-6">
        {/* Title */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Complaint Title *
          </label>
          <input
            type="text"
            name="title"
            required
            value={formData.title}
            onChange={handleChange}
            placeholder="e.g. Flickering Ceiling Projector in Seminar Hall 101"
            className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 text-sm font-medium"
          />
        </div>

        {/* Category & Priority */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Category *
            </label>
            <select
              name="category"
              value={formData.category}
              onChange={handleChange}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 text-sm bg-white font-medium"
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Priority Urgency *
            </label>
            <select
              name="priority"
              value={formData.priority}
              onChange={handleChange}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 text-sm bg-white font-medium"
            >
              <option value="Low">Low (Minor cosmetic / non-urgent)</option>
              <option value="Medium">Medium (Routine maintenance)</option>
              <option value="High">High (Safety risk / classes interrupted)</option>
            </select>
          </div>
        </div>

        {/* Location & Room */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Campus Building / Area *
            </label>
            <select
              name="location"
              value={formData.location}
              onChange={handleChange}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 text-sm bg-white font-medium"
            >
              {locations.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Room / Desk / Specific Area (Optional)
            </label>
            <input
              type="text"
              name="roomNumber"
              value={formData.roomNumber}
              onChange={handleChange}
              placeholder="e.g. Room 204, 3rd Floor East Wing"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 text-sm font-medium"
            />
          </div>
        </div>

        {/* Description */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Detailed Issue Description *
          </label>
          <textarea
            rows={4}
            name="description"
            required
            value={formData.description}
            onChange={handleChange}
            placeholder="Please specify what went wrong, when it started, and how it impacts students or faculty..."
            className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 text-sm font-medium"
          />
        </div>

        {/* Optional Image Upload */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Attach Photo Evidence (Optional, max 5MB)
          </label>
          {previewUrl ? (
            <div className="relative inline-block border border-slate-200 rounded-2xl p-2 bg-slate-50">
              <img
                src={previewUrl}
                alt="Attachment preview"
                className="w-36 h-36 object-cover rounded-xl"
              />
              <button
                type="button"
                onClick={removeFile}
                className="absolute -top-2 -right-2 p-1.5 bg-rose-600 text-white rounded-full shadow-md hover:bg-rose-700 transition-colors cursor-pointer"
                title="Remove photo"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <div className="border-2 border-dashed border-slate-300 hover:border-teal-500 rounded-2xl p-6 text-center transition-colors">
              <input
                type="file"
                id="file-input"
                accept="image/jpeg,image/png,image/webp"
                onChange={handleFileChange}
                className="hidden"
              />
              <label
                htmlFor="file-input"
                className="cursor-pointer flex flex-col items-center justify-center gap-2"
              >
                <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center">
                  <Upload className="w-5 h-5 text-teal-600" />
                </div>
                <span className="text-xs font-bold text-slate-800">
                  Click to select photo (JPG, PNG, WebP)
                </span>
                <span className="text-[11px] text-slate-400">
                  Photos help facility teams identify necessary replacement parts faster
                </span>
              </label>
            </div>
          )}
        </div>

        {/* Buttons */}
        <div className="pt-4 border-t border-slate-100 flex flex-col-reverse sm:flex-row items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleReset}
            className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 text-xs font-bold hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Form
          </button>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-md shadow-teal-600/20 transition-all disabled:opacity-50 cursor-pointer"
          >
            {isSubmitting ? (
              <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <PlusCircle className="w-4 h-4" />
                Submit Grievance
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default SubmitComplaint;
