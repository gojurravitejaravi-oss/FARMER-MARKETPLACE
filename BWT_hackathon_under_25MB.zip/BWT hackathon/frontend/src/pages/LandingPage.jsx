import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  ShieldAlert,
  Zap,
  CheckCircle2,
  Clock,
  ArrowRight,
  Sparkles,
  Users,
  Building,
  Wifi,
  Droplets,
  Lightbulb,
  BookOpen,
  Cpu,
  Lock,
  BarChart3,
  Flame,
  FileCheck2,
  AlertTriangle,
} from 'lucide-react';

const LandingPage = () => {
  const { isAuthenticated, isAdmin } = useAuth();

  const categories = [
    { name: 'Electricity & Power', icon: Zap, desc: 'Flickering lights, blown fuses, exposed cables' },
    { name: 'Water & Plumbing', icon: Droplets, desc: 'Washroom leaks, low pressure, broken taps' },
    { name: 'Wi-Fi & Networks', icon: Wifi, desc: 'Access point drops, lab connectivity, slow bandwidth' },
    { name: 'Classroom Facilities', icon: BookOpen, desc: 'Damaged projectors, podium microphones, ACs' },
    { name: 'Laboratory Hardware', icon: Cpu, desc: 'Workbench outlets, equipment maintenance' },
    { name: 'Hygiene & Cleanliness', icon: Sparkles, desc: 'Waste disposal, sanitization, corridor maintenance' },
    { name: 'Campus Safety', icon: ShieldAlert, desc: 'Emergency exits, fire extinguisher checks, lighting' },
    { name: 'Furniture & Fixtures', icon: Building, desc: 'Broken lecture desks, broken chairs, doors' },
  ];

  const workflowSteps = [
    {
      num: '01',
      title: 'Student Lodges Complaint',
      desc: 'Fill category, building, room number, description, priority, and optional photos. Validated securely on client and backend.',
      icon: Users,
    },
    {
      num: '02',
      title: 'Unique Ticket Generated',
      desc: 'System assigns an immutable reference identifier (e.g. CMP-2026-10482) and initializes status to Pending in MongoDB.',
      icon: FileCheck2,
    },
    {
      num: '03',
      title: 'Admin Reviews & Dispatches',
      desc: 'Facility managers review priorities, assign responsible teams, and record updates with official administrative remarks.',
      icon: Clock,
    },
    {
      num: '04',
      title: 'Verified Resolution',
      desc: 'Work verified on-site, status changed to Resolved, resolution notes logged, and students receive closure with complete audit trail.',
      icon: CheckCircle2,
    },
  ];

  return (
    <div className="space-y-24 pb-20">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 sm:pt-20 lg:pt-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-50 border border-teal-200 text-teal-800 text-xs font-semibold tracking-wide shadow-xs animate-fade-in">
              <Sparkles className="w-4 h-4 text-teal-600" />
              <span>Next-Generation Campus Facility & Grievance Management</span>
            </div>

            <h1 className="text-4xl sm:text-6xl font-black text-slate-900 tracking-tight leading-tight">
              Campus Complaint <br className="hidden sm:inline" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-slate-900 via-teal-800 to-teal-600">
                Management System
              </span>
            </h1>

            <p className="text-xl sm:text-2xl font-bold text-teal-700 tracking-wide">
              Report. Track. Resolve.
            </p>

            <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
              Eliminate lost paper complaints and endless delays. A centralized, transparent MERN platform for students to lodge campus issues and administrators to dispatch quick resolutions.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              {isAuthenticated ? (
                <Link
                  to={isAdmin ? '/admin/dashboard' : '/student/dashboard'}
                  className="w-full sm:w-auto flex items-center justify-center gap-2 px-7 py-3.5 rounded-2xl bg-slate-900 text-white font-bold text-base hover:bg-slate-800 shadow-md shadow-slate-900/10 transition-all"
                >
                  Go to {isAdmin ? 'Admin' : 'Student'} Dashboard
                  <ArrowRight className="w-5 h-5 text-teal-400" />
                </Link>
              ) : (
                <>
                  <Link
                    to="/register"
                    className="w-full sm:w-auto flex items-center justify-center gap-2 px-7 py-3.5 rounded-2xl bg-teal-600 text-white font-bold text-base hover:bg-teal-700 shadow-md shadow-teal-600/20 transition-all"
                  >
                    Lodge a Complaint
                    <ArrowRight className="w-5 h-5" />
                  </Link>
                  <Link
                    to="/login"
                    className="w-full sm:w-auto flex items-center justify-center gap-2 px-7 py-3.5 rounded-2xl bg-white border border-slate-300 text-slate-800 font-bold text-base hover:bg-slate-50 shadow-xs transition-all"
                  >
                    Sign In / Admin Portal
                  </Link>
                </>
              )}
            </div>

            {/* Quick Demo Evaluation Box */}
            <div className="pt-8 max-w-xl mx-auto">
              <div className="bg-white/80 backdrop-blur-md rounded-2xl p-4 border border-slate-200/90 shadow-sm text-left">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-teal-600" />
                    Quick Hackathon Evaluation Credentials
                  </span>
                  <Link
                    to="/login"
                    className="text-xs font-semibold text-teal-600 hover:text-teal-700 flex items-center gap-1"
                  >
                    Open Login <ArrowRight className="w-3 h-3" />
                  </Link>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
                    <span className="font-bold text-slate-900 block text-xs mb-0.5">Administrator Account</span>
                    <p className="text-slate-600 font-mono text-[11px]">Email: admin@campus.edu</p>
                    <p className="text-slate-600 font-mono text-[11px]">Pass: Admin@123456</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-teal-50/50 border border-teal-100">
                    <span className="font-bold text-teal-900 block text-xs mb-0.5">Student Account</span>
                    <p className="text-slate-600 font-mono text-[11px]">Email: student@campus.edu</p>
                    <p className="text-slate-600 font-mono text-[11px]">Pass: Student@123456</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Problem vs Solution Comparison */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-xs font-bold uppercase tracking-widest text-teal-700 mb-2">
            The Transformation
          </h2>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            Why Campus Grievance Systems Fail Without Modern Tech
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Old Method */}
          <div className="p-6 sm:p-8 rounded-3xl bg-rose-50/50 border border-rose-200/80 shadow-xs space-y-4">
            <div className="flex items-center gap-2.5 text-rose-700 font-bold text-lg">
              <AlertTriangle className="w-6 h-6" />
              <h3>The Legacy Manual Approach</h3>
            </div>
            <ul className="space-y-3 text-sm text-slate-700">
              <li className="flex items-start gap-2.5">
                <span className="text-rose-500 font-bold">✕</span>
                <span>Paper complaint registers left unattended in department offices.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-rose-500 font-bold">✕</span>
                <span>Zero visibility for students on who is handling their grievance.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-rose-500 font-bold">✕</span>
                <span>Critical safety or electrical hazards get buried without priority triage.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-rose-500 font-bold">✕</span>
                <span>No accountability, no timestamped history, and repeat complaints.</span>
              </li>
            </ul>
          </div>

          {/* New Solution */}
          <div className="p-6 sm:p-8 rounded-3xl bg-teal-50/50 border border-teal-200/80 shadow-xs space-y-4">
            <div className="flex items-center gap-2.5 text-teal-800 font-bold text-lg">
              <CheckCircle2 className="w-6 h-6 text-teal-600" />
              <h3>The CampusResolve Platform</h3>
            </div>
            <ul className="space-y-3 text-sm text-slate-700">
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span>Instant digital ticket generation with searchable unique reference code.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span>Role-based dashboards for instant administrative inspection and technician routing.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span>Transparent status timeline: Pending → In Progress → Resolved.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span>MongoDB persistence with audit-ready historical tracking and remarks.</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Core Workflow Section */}
      <section id="how-it-works" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-xs font-bold uppercase tracking-widest text-teal-700 mb-2">
            End-To-End Architecture
          </h2>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            How CampusResolve Closes the Loop
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {workflowSteps.map((s) => {
            const Icon = s.icon;
            return (
              <div
                key={s.num}
                className="relative bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-black text-slate-300">{s.num}</span>
                    <div className="w-10 h-10 rounded-xl bg-slate-900 text-teal-400 flex items-center justify-center">
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mb-2">{s.title}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">{s.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Categories Grid */}
      <section id="categories" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-xs font-bold uppercase tracking-widest text-teal-700 mb-2">
            Coverage Scope
          </h2>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            Comprehensive Campus Grievance Categories
          </p>
          <p className="text-sm text-slate-600 mt-2">
            Every critical facility is mapped to dedicated departmental maintenance teams.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {categories.map((cat) => {
            const Icon = cat.icon;
            return (
              <div
                key={cat.name}
                className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-2xs hover:border-teal-500/50 hover:shadow-sm transition-all group"
              >
                <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center mb-3 group-hover:bg-slate-900 group-hover:text-teal-400 transition-colors">
                  <Icon className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-bold text-slate-900 mb-1">{cat.name}</h4>
                <p className="text-xs text-slate-500 leading-normal">{cat.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Feature Pillars */}
      <section id="features" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 rounded-3xl p-8 sm:p-12 text-white">
          <div className="max-w-3xl mx-auto text-center space-y-4 mb-12">
            <span className="text-xs font-bold uppercase tracking-widest text-teal-400">
              Enterprise Grade Engineering
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight">
              Designed for Scale, Reliability, and Zero Data Loss
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-6 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center">
                <Lock className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-white">Strict Role-Based Security</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Cryptographically hashed passwords, signed JWT tokens, and backend middleware that blocks students from altering status or accessing other students' records.
              </p>
            </div>

            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-6 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center">
                <BarChart3 className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-white">Actionable Admin Intelligence</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Real-time MongoDB aggregation metrics: category bottlenecks, high-priority issues, SLA tracking, and instant filtering across all submissions.
              </p>
            </div>

            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-6 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center">
                <Clock className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-white">Transparent Audit Timeline</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Every status change documents previous state, new state, administrator identity, timestamp, and actionable notes directly stored in the complaint document.
              </p>
            </div>
          </div>

          <div className="mt-12 text-center pt-8 border-t border-slate-800">
            <Link
              to="/register"
              className="inline-flex items-center gap-2 px-8 py-3 rounded-2xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-extrabold text-sm shadow-lg shadow-teal-500/20 transition-all"
            >
              Get Started Now — Register As Student
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
