import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import StatusBadge from '../components/StatusBadge';
import PriorityBadge from '../components/PriorityBadge';
import { LoadingSpinner } from '../components/LoadingSpinner';
import {
  ArrowLeft,
  MapPin,
  Calendar,
  User,
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Briefcase,
  FileText,
  Send,
  MessageSquare,
  Building,
  Hash,
  Trash2,
} from 'lucide-react';

const ComplaintDetails = () => {
  const { id } = useParams();
  const { user, isAdmin } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();

  const [complaint, setComplaint] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Admin update form state
  const [adminStatus, setAdminStatus] = useState('In Progress');
  const [adminRemarks, setAdminRemarks] = useState('');
  const [assignedDepartment, setAssignedDepartment] = useState('');
  const [assignedTo, setAssignedTo] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  const fetchComplaintDetails = async () => {
    try {
      setLoading(true);
      const res = await api.get(`/complaints/${id}`);
      if (res.data.success) {
        setComplaint(res.data.complaint);
        setAdminStatus(res.data.complaint.status);
        setAssignedDepartment(res.data.complaint.assignedDepartment || '');
        setAssignedTo(res.data.complaint.assignedTo || '');
      }
    } catch (err) {
      console.error('Fetch complaint error:', err);
      const msg = err.response?.data?.message || 'Unable to fetch complaint details.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchComplaintDetails();
  }, [id]);

  const handleAdminStatusUpdate = async (e) => {
    e.preventDefault();
    try {
      setIsUpdating(true);
      const res = await api.patch(`/complaints/${complaint._id}/status`, {
        status: adminStatus,
        adminRemarks: adminRemarks.trim(),
        resolutionNotes: adminStatus === 'Resolved' ? adminRemarks.trim() : undefined,
        assignedDepartment: assignedDepartment.trim(),
        assignedTo: assignedTo.trim(),
      });

      if (res.data.success) {
        toast.success(`Complaint status changed to ${adminStatus}`);
        setComplaint(res.data.complaint);
        setAdminRemarks('');
      }
    } catch (err) {
      console.error('Admin status update error:', err);
      const msg = err.response?.data?.message || 'Failed to update complaint status.';
      toast.error(msg);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleDeleteComplaint = async () => {
    if (!window.confirm('Are you sure you want to delete this pending complaint? This cannot be undone.')) {
      return;
    }

    try {
      const res = await api.delete(`/complaints/${complaint._id}`);
      if (res.data.success) {
        toast.success('Complaint removed successfully.');
        navigate(isAdmin ? '/admin/complaints' : '/student/complaints');
      }
    } catch (err) {
      const msg = err.response?.data?.message || 'Failed to delete complaint.';
      toast.error(msg);
    }
  };

  if (loading) {
    return <LoadingSpinner text="Loading ticket tracking details..." />;
  }

  if (error || !complaint) {
    return (
      <div className="max-w-xl mx-auto py-12 text-center space-y-4">
        <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 mx-auto flex items-center justify-center">
          <AlertTriangle className="w-6 h-6" />
        </div>
        <h3 className="text-lg font-bold text-slate-800">Cannot Access Complaint</h3>
        <p className="text-xs text-slate-500">{error || 'This complaint record could not be found.'}</p>
        <button
          onClick={() => navigate(-1)}
          className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-semibold cursor-pointer"
        >
          Go Back
        </button>
      </div>
    );
  }

  const backLink = isAdmin ? '/admin/complaints' : '/student/complaints';

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in pb-16">
      {/* Back button & Ticket Number Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <Link
          to={backLink}
          className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Complaints Directory
        </Link>

        {/* Delete button if owner and pending */}
        {(isAdmin || (complaint.student?._id === user?.id && complaint.status === 'Pending')) && (
          <button
            onClick={handleDeleteComplaint}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-rose-200 text-rose-600 hover:bg-rose-50 text-xs font-semibold cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Delete Ticket
          </button>
        )}
      </div>

      {/* Main Ticket Summary Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5">
              <span className="font-mono text-base sm:text-lg font-black text-teal-800 bg-teal-50 px-3 py-1 rounded-lg border border-teal-200">
                {complaint.complaintNumber}
              </span>
              <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-md">
                {complaint.category}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 pt-2">
              {complaint.title}
            </h2>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <PriorityBadge priority={complaint.priority} />
            <StatusBadge status={complaint.status} size="lg" />
          </div>
        </div>

        {/* Metadata Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-slate-400 font-semibold block mb-1">Campus Location</span>
            <div className="font-bold text-slate-800 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-teal-600" />
              {complaint.location}
            </div>
            {complaint.roomNumber && (
              <span className="text-[11px] text-slate-500 mt-0.5 block">
                Room: {complaint.roomNumber}
              </span>
            )}
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-slate-400 font-semibold block mb-1">Lodged By</span>
            <div className="font-bold text-slate-800 flex items-center gap-1.5">
              <User className="w-4 h-4 text-teal-600" />
              {complaint.student?.name || 'Student'}
            </div>
            <span className="text-[11px] text-slate-500 mt-0.5 block truncate">
              {complaint.student?.department || 'Student'}
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-slate-400 font-semibold block mb-1">Assigned Department</span>
            <div className="font-bold text-slate-800 flex items-center gap-1.5">
              <Briefcase className="w-4 h-4 text-teal-600" />
              {complaint.assignedDepartment || 'General Maintenance'}
            </div>
            {complaint.assignedTo && (
              <span className="text-[11px] text-slate-500 mt-0.5 block">
                Tech: {complaint.assignedTo}
              </span>
            )}
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-slate-400 font-semibold block mb-1">Submission Date</span>
            <div className="font-bold text-slate-800 flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-teal-600" />
              {new Date(complaint.createdAt).toLocaleDateString()}
            </div>
            <span className="text-[11px] text-slate-500 mt-0.5 block">
              {new Date(complaint.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        </div>

        {/* Detailed Description */}
        <div className="space-y-2 pt-2">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Issue Description
          </h4>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-sm text-slate-800 leading-relaxed whitespace-pre-line">
            {complaint.description}
          </div>
        </div>

        {/* Attachment preview if exists */}
        {complaint.attachmentUrl && (
          <div className="space-y-2 pt-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Attached Photo Evidence
            </h4>
            <div className="p-2 rounded-2xl border border-slate-200 inline-block bg-slate-50">
              <img
                src={`http://localhost:5000${complaint.attachmentUrl}`}
                alt="Complaint attachment"
                className="max-h-64 rounded-xl object-contain"
                onError={(e) => {
                  e.target.style.display = 'none';
                }}
              />
            </div>
          </div>
        )}

        {/* Resolution Notes Banner if Resolved */}
        {complaint.status === 'Resolved' && (
          <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 space-y-1.5">
            <div className="flex items-center gap-2 font-bold text-emerald-800 text-sm">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              Complaint Resolved & Verified
            </div>
            {complaint.resolutionNotes && (
              <p className="text-xs text-emerald-800 leading-relaxed">
                <strong>Resolution Note:</strong> {complaint.resolutionNotes}
              </p>
            )}
            {complaint.resolvedAt && (
              <p className="text-[11px] text-emerald-700">
                Resolved on: {new Date(complaint.resolvedAt).toLocaleString()}
              </p>
            )}
          </div>
        )}
      </div>

      {/* Admin Action Panel (Only visible to Admin) */}
      {isAdmin && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-purple-200 shadow-md shadow-purple-900/5 space-y-6">
          <div className="flex items-center gap-2.5 pb-4 border-b border-purple-100">
            <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Administrative Action & Status Update
              </h3>
              <p className="text-xs text-slate-500">
                Update status, assign departments, and append official remarks to the audit trail.
              </p>
            </div>
          </div>

          <form onSubmit={handleAdminStatusUpdate} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Change Status *
                </label>
                <select
                  value={adminStatus}
                  onChange={(e) => setAdminStatus(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-purple-500 text-xs bg-white font-semibold"
                >
                  <option value="Pending">Pending</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Resolved">Resolved</option>
                  <option value="Rejected">Rejected</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Assigned Department
                </label>
                <input
                  type="text"
                  value={assignedDepartment}
                  onChange={(e) => setAssignedDepartment(e.target.value)}
                  placeholder="e.g. Electrical Services"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-purple-500 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Technician / Handler
                </label>
                <input
                  type="text"
                  value={assignedTo}
                  onChange={(e) => setAssignedTo(e.target.value)}
                  placeholder="e.g. Rajesh Kumar"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-purple-500 text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Official Remark / Resolution Note
              </label>
              <textarea
                rows={2}
                value={adminRemarks}
                onChange={(e) => setAdminRemarks(e.target.value)}
                placeholder="Explain the inspection status, parts ordered, or resolution summary for the student to see..."
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-purple-500 text-xs"
              />
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={isUpdating}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs shadow-md transition-all disabled:opacity-50 cursor-pointer"
              >
                {isUpdating ? (
                  <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    Commit Status Update
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Status History Timeline Audit Trail */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-sm space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-teal-600" />
            <h3 className="text-base font-bold text-slate-900">
              Audit Status History Timeline
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-medium">
            {complaint.statusHistory?.length || 0} events recorded
          </span>
        </div>

        <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
          {complaint.statusHistory?.map((step, idx) => (
            <div key={idx} className="relative group text-xs">
              <div className="absolute -left-6 top-1 w-3.5 h-3.5 rounded-full bg-white border-2 border-teal-500 shadow-2xs" />
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 text-sm">
                    {step.newStatus}
                  </span>
                  {step.previousStatus && (
                    <span className="text-[11px] text-slate-400">
                      (from {step.previousStatus})
                    </span>
                  )}
                </div>
                <span className="text-[11px] text-slate-400">
                  {new Date(step.timestamp).toLocaleString()}
                </span>
              </div>

              {step.remarks && (
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-slate-700 text-xs italic mt-1.5">
                  "{step.remarks}"
                </div>
              )}

              <div className="text-[11px] text-slate-400 mt-1">
                Updated by: <span className="font-medium text-slate-600">{step.updatedByName}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ComplaintDetails;
