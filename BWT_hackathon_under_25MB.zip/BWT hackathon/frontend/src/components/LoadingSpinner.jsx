import React from 'react';

export const LoadingSpinner = ({ size = 'md', text = 'Loading data...' }) => {
  const sizeMap = {
    sm: 'w-5 h-5 border-2',
    md: 'w-8 h-8 border-3',
    lg: 'w-12 h-12 border-4',
  };

  return (
    <div className="flex flex-col items-center justify-center p-8 gap-3 text-slate-500">
      <div
        className={`${sizeMap[size] || sizeMap.md} border-teal-500 border-t-transparent rounded-full animate-spin`}
      />
      {text && <p className="text-sm font-medium text-slate-600">{text}</p>}
    </div>
  );
};

export const CardSkeleton = () => (
  <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs animate-pulse">
    <div className="flex justify-between items-start mb-3">
      <div className="h-4 bg-slate-200 rounded w-28"></div>
      <div className="h-5 bg-slate-200 rounded-full w-20"></div>
    </div>
    <div className="h-6 bg-slate-200 rounded w-3/4 mb-2"></div>
    <div className="h-4 bg-slate-200 rounded w-1/2 mb-4"></div>
    <div className="pt-3 border-t border-slate-100 flex justify-between">
      <div className="h-4 bg-slate-200 rounded w-24"></div>
      <div className="h-4 bg-slate-200 rounded w-16"></div>
    </div>
  </div>
);

export default LoadingSpinner;
