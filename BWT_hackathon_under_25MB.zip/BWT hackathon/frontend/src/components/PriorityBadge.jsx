import React from 'react';
import { AlertCircle, ArrowDown, ArrowUp } from 'lucide-react';

const PriorityBadge = ({ priority }) => {
  const p = (priority || 'Medium').toLowerCase();

  if (p === 'high' || p === 'urgent') {
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
        <ArrowUp className="w-3 h-3 text-rose-600" />
        High
      </span>
    );
  }

  if (p === 'low') {
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
        <ArrowDown className="w-3 h-3 text-slate-500" />
        Low
      </span>
    );
  }

  // Medium
  return (
    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
      <AlertCircle className="w-3 h-3 text-amber-500" />
      Medium
    </span>
  );
};

export default PriorityBadge;
