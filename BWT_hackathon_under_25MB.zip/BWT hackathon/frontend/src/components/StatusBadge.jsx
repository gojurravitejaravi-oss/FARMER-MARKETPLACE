import React from 'react';
import { Clock, RefreshCw, CheckCircle2, XCircle } from 'lucide-react';

const StatusBadge = ({ status, size = 'sm' }) => {
  const normalized = (status || 'Pending').trim();

  let config = {
    bg: 'bg-amber-50 text-amber-800 border-amber-200/80',
    dot: 'bg-amber-500',
    icon: Clock,
    label: 'Pending',
  };

  if (normalized === 'In Progress') {
    config = {
      bg: 'bg-blue-50 text-blue-800 border-blue-200/80',
      dot: 'bg-blue-500 animate-pulse',
      icon: RefreshCw,
      label: 'In Progress',
    };
  } else if (normalized === 'Resolved') {
    config = {
      bg: 'bg-emerald-50 text-emerald-800 border-emerald-200/80',
      dot: 'bg-emerald-500',
      icon: CheckCircle2,
      label: 'Resolved',
    };
  } else if (normalized === 'Rejected') {
    config = {
      bg: 'bg-rose-50 text-rose-800 border-rose-200/80',
      dot: 'bg-rose-500',
      icon: XCircle,
      label: 'Rejected',
    };
  }

  const Icon = config.icon;
  const isSm = size === 'sm';

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-medium rounded-full border ${config.bg} ${
        isSm ? 'px-2.5 py-0.5 text-xs' : 'px-3.5 py-1 text-sm'
      }`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${config.dot}`} />
      <Icon className={isSm ? 'w-3 h-3' : 'w-4 h-4'} />
      {config.label}
    </span>
  );
};

export default StatusBadge;
